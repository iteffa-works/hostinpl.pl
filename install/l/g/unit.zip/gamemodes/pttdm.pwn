//------------------------------------------------------------------------------
//
// Portland Team Deathmatch, originally by Cam - Edited by Sebihunter
//
//------------------------------------------------------------------------------

#include <a_samp>
#include <core>
#include <float>

//Global stuff and defines for our gamemode
static gTeam[MAX_PLAYERS]; // Tracks the team assignment for each player
new gPlayerClass[MAX_PLAYERS];

//Color Defines
#define COLOR_GREY 0xAFAFAFAA
#define COLOR_GREEN 0x33AA33AA
#define COLOR_RED 0xAA3333AA
#define COLOR_YELLOW 0xFFFF00AA
#define COLOR_PINK 0xFF66FFAA
#define COLOR_BLUE 0x0000BBAA
#define COLOR_LIGHTBLUE 0x33CCFFAA
#define COLOR_DARKRED 0x660000AA
#define COLOR_ORANGE 0xFF9900AA

//Team Defines
#define TEAM_GROVE 0
#define TEAM_MAFIA 1
#define TEAM_POLICE 2


// Round duration
new gRoundTime = 0;
//new gRoundTime = 3600000; // 60 mins
//new gRoundTime = 900000; //15 mins
//new gRoundTime = 300000; // 5 mins

forward SetupPlayerForClassSelection(playerid);
forward GameModeExitFunc();

//------------------------------------------------------------------------------
main() {
	print("*********************");
	print("GTA:U MultiPlayer");
	print("Portland TDM");
	print("Based on SFTDM by mike");
	print("Converted by Sebihunter");
	print("*********************");
}

//------------------------------------------------------------------------------
public OnGameModeInit()
{
	SetGameModeText("Portland TDM");
	SetTeamCount(7);
	ShowNameTags(1);
	ShowPlayerMarkers(1);
	SetWorldTime(18);

	AddPlayerClass(106,-460.5335,1500.5801,8.7751,185.9785,42,400,30,100,32,200);//Grove
	AddPlayerClass(113,111.0701,1626.1619,55.7378,168.8894,22,272,25,40,4,1); // Mafia
	AddPlayerClass(280,-201.8634,1124.8555,14.9441,90.9029,42,400,31,100,29,200);//Police

	AddStaticVehicle(588,-119.5545,684.5014,11.7274,270.4689,1,1); //
	AddStaticVehicle(437,-45.0599,828.6925,14.9811,43.1290,79,7); //
	AddStaticVehicle(456,-181.9137,754.3018,14.9623,182.6016,91,63); //
	AddStaticVehicle(420,-483.0838,806.3025,4.7884,0.1123,6,1); //
	AddStaticVehicle(515,-451.8860,807.4700,6.0363,271.2491,24,77); //
	AddStaticVehicle(587,-248.0060,829.6306,14.6314,271.8468,53,1); //
	AddStaticVehicle(560,-186.7920,852.5982,14.7731,43.3272,9,39); //
	AddStaticVehicle(587,-129.0578,902.2985,14.7925,179.0804,72,1); //
	AddStaticVehicle(420,-95.8115,1044.5586,14.9071,46.0426,6,1); //
	AddStaticVehicle(438,-93.8981,1046.9655,15.1282,48.3067,6,76); //
	AddStaticVehicle(438,-92.0073,1049.5994,15.1296,43.3536,6,76); //
	AddStaticVehicle(445,-342.4889,953.5015,14.7983,86.1361,35,35); //
	AddStaticVehicle(411,-322.4866,926.5102,14.6486,269.6855,64,1); //
	AddStaticVehicle(560,-454.5258,897.6379,14.6395,268.5732,17,1); //
	AddStaticVehicle(411,-42.7606,1159.2147,11.9010,4.8970,116,1); //
	AddStaticVehicle(402,-62.0116,1166.7595,12.0031,266.2639,13,13); //
	AddStaticVehicle(402,-435.6074,1064.4036,14.6017,89.8929,22,22); //
	AddStaticVehicle(437,-308.1472,1148.6996,14.9858,179.4331,87,7); //
	AddStaticVehicle(411,-288.7233,1098.9949,14.5816,4.6308,112,1); //
	AddStaticVehicle(602,-509.4891,1201.7792,14.6595,0.9288,69,1); //
	AddStaticVehicle(537,-584.5000,1222.7932,24.2204,0.0000,1,1); //
	AddStaticVehicle(475,-379.9390,1276.1538,14.6585,180.5723,17,1); //
	AddStaticVehicle(567,-413.1388,1216.5260,14.7165,88.3618,88,64); //
	AddStaticVehicle(411,-397.0738,1424.1033,14.0397,354.2865,112,1); //
	AddStaticVehicle(567,-479.5892,1489.5557,8.4583,177.3838,90,96); //
	AddStaticVehicle(567,-484.0524,1489.9647,8.4657,175.8425,93,64); //
	AddStaticVehicle(567,-488.0551,1489.3263,8.6201,180.4333,97,96); //
	AddStaticVehicle(567,-475.0431,1489.2625,8.5584,173.4313,99,81); //
	AddStaticVehicle(475,-401.4320,1543.8623,4.6837,230.6721,21,1); //
	AddStaticVehicle(541,-386.6533,1664.7389,4.5655,180.4475,58,8); //
	AddStaticVehicle(522,-280.4835,1386.6190,14.9092,80.3133,3,8); //
	AddStaticVehicle(456,-265.1551,1570.9119,9.1870,10.7126,102,65); //
	AddStaticVehicle(407,-243.1876,1762.9478,7.6872,267.9881,3,1); //
	AddStaticVehicle(560,-416.4247,1736.9629,7.9375,87.6519,21,1); //
	AddStaticVehicle(587,-205.5811,1704.5375,7.1625,182.0467,53,1); //
	AddStaticVehicle(451,-79.0631,1702.8870,14.5385,95.8809,125,125); //
	AddStaticVehicle(602,-138.9913,1547.2427,24.7473,262.7385,75,77); //
	AddStaticVehicle(445,-141.7954,1413.1759,25.0835,88.7010,37,37); //
	AddStaticVehicle(541,74.0101,1616.3739,50.0975,88.0325,60,1); //
	AddStaticVehicle(411,75.2010,1627.8346,50.4413,88.8048,106,1); //
	AddStaticVehicle(491,58.2033,1622.8228,50.1102,281.0352,71,72); //
	AddStaticVehicle(461,56.8685,1628.6635,50.1426,324.4399,37,1); //
	AddStaticVehicle(461,74.7363,1622.4105,50.1812,73.8837,43,1); //
	AddStaticVehicle(468,60.4438,1617.6771,49.9930,332.7465,46,46); //
	AddStaticVehicle(596,-211.2722,1160.2928,14.6624,178.5691,0,1); // Police Car (LSPD)
	AddStaticVehicle(596,-204.9340,1160.6375,14.6513,176.4668,0,1); // Police Car (LSPD)
	AddStaticVehicle(596,-211.1160,1109.6191,14.6617,2.5693,0,1); // Police Car (LSPD)
	AddStaticVehicle(596,-206.9621,1109.6797,14.6649,2.4006,0,1); // Police Car (LSPD)
	AddStaticVehicle(596,-203.2096,1110.0220,14.6765,355.7207,0,1); // Police Car (LSPD)

	if(gRoundTime > 0) SetTimer("GameModeExitFunc", gRoundTime, 0);

	return 1;
}

//------------------------------------------------------------------------------
public OnPlayerConnect(playerid)
{
	GameTextForPlayer(playerid,"Portland: ~r~TDM",2500,5);
	SendRconCommand("mapname Liberty City");
	GivePlayerMoney(playerid, 1000);
	SendClientMessage(playerid,0xFFFF00AA,"Welcome to Portland TDM, by Sebihunter & mike");
	SendClientMessage(playerid,0xFFFF00AA,"Enjoy your stay at the GTA:U Multiplayer Beta!");

	SetPlayerColor(playerid, COLOR_ORANGE); // Set the player's color to inactive

	return 1;
}



//------------------------------------------------------------------------------
public OnPlayerSpawn(playerid)
{
	SetPlayerInterior(playerid,0);
	if(gTeam[playerid] == TEAM_GROVE) {
		SetPlayerColor(playerid,COLOR_GREEN); // Green
	}
	if(gTeam[playerid] == TEAM_MAFIA) {
		SetPlayerColor(playerid,COLOR_GREY); // Grey
	}
	if(gTeam[playerid] == TEAM_POLICE) {
		SetPlayerColor(playerid,COLOR_BLUE); // Blue
	}

	return 1;
}

//------------------------------------------------------------------------------
public OnPlayerDeath(playerid, killerid, reason)
{
	if(killerid == INVALID_PLAYER_ID) {
		SendDeathMessage(INVALID_PLAYER_ID,playerid,reason);
	} else {
		if(gTeam[killerid] != gTeam[playerid]) {
			// Valid kill
			SendDeathMessage(killerid,playerid,reason);
			SetPlayerScore(killerid,GetPlayerScore(killerid)+1);
			GivePlayerMoney(killerid, 1000);
		}
		else {
			//Team Killer!
			new warning[256];
			format(warning, sizeof(warning), "Be careful! You have been punished for teamkilling.");
			SendClientMessage(killerid, 0xFFFF00AA, warning);
			SendDeathMessage(killerid,playerid,reason);
			GivePlayerMoney(killerid, -1000);
			SetPlayerScore(killerid, GetPlayerScore(killerid) - 1);
		}
	}

	return 1;
}

//------------------------------------------------------------------------------
public SetupPlayerForClassSelection(playerid)
{
	SetPlayerInterior(playerid,14);
	SetPlayerPos(playerid,258.4893,-41.4008,1002.0234);
	SetPlayerFacingAngle(playerid, 90.0);
	SetPlayerCameraPos(playerid,256.0815,-43.0475,1003.0234);
	SetPlayerCameraLookAt(playerid,258.4893,-41.4008,1002.0234);
}

//------------------------------------------------------------------------------
public OnPlayerRequestClass(playerid, classid)
{
	SetPlayerClass(playerid, classid);
	SetupPlayerForClassSelection(playerid);
	gPlayerClass[playerid] = classid;
	switch (classid) {
		case 0:
		{
			GameTextForPlayer(playerid, "~g~Grove Sreet", 500, 3);
		}
		case 1:
		{
			GameTextForPlayer(playerid, "~w~Mafia", 500, 3);
		}
		case 2:
		{
			GameTextForPlayer(playerid, "~b~Police", 500, 3);
		}
	}
	return 1;
}

//------------------------------------------------------------------------------
public GameModeExitFunc()
{
	GameModeExit();
	return 1;
}

//------------------------------------------------------------------------------
SetPlayerClass(playerid, classid) {
	if(classid == 0) {
		gTeam[playerid] = TEAM_GROVE;
	}
	if(classid == 1) {
		gTeam[playerid] = TEAM_MAFIA;
	}
	if(classid == 2) {
		gTeam[playerid] = TEAM_POLICE;
	}
}

//------------------------------------------------------------------------------
