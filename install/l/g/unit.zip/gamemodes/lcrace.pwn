#include <a_samp>

#define COLOR_YELLOW 0xFFFF00AA
#define COLOR_WHITE 0xFFFFFFAA
#define INACTIVE_PLAYER_ID INVALID_PLAYER_ID

#define COLOR_GREY 			0xAFAFAFAA
#define COLOR_PURPLE 		0xC2A2DAAA
#define COLOR_YELLOW 		0xFFFF00AA
#define COLOR_WHITE 		0xFFFFFFAA
#define COLOR_DBLUE 		0x2641FEAA
#define COLOR_BLUE 			0x33AAFFFF
#define COLOR_GREEN 		0x33AA33AA
#define COLOR_ORANGE 		0xFF9900AA
#define COLOR_GREY 			0xAFAFAFAA
#define COLOR_GREEN 		0x33AA33AA
#define COLOR_RED 			0xAA3333AA
#define COLOR_LIGHTRED 		0xFF6347AA
#define COLOR_LIGHTBLUE 	0x33CCFFAA
#define COLOR_LIGHTGREEN 	0x9ACD32AA
#define COLOR_YELLOW 		0xFFFF00AA
#define COLOR_YELLOW2 		0xF5DEB3AA
#define COLOR_WHITE 		0xFFFFFFAA
#define COLOR_FADE1 		0xE6E6E6E6
#define COLOR_FADE2 		0xC8C8C8C8
#define COLOR_FADE3 		0xAAAAAAAA
#define COLOR_FADE4 		0x8C8C8C8C
#define COLOR_FADE5 		0x6E6E6E6E
#define COLOR_PURPLE 		0xC2A2DAAA
#define COLOR_DBLUE 		0x2641FEAA
#define COLOR_CYAN 			0x00FFFFAA
#define COLOR_SYSTEM 		0xEFEFF7AA

forward BeginRace2();
forward BeginRace();
forward GameModeExitFunc();
forward DefenceWin();

forward TimeIsOver();
forward LastRacer();
forward ChangeMode();

forward SetupPlayerForClassSelection(playerid);

#define MAXCP 27
new Float:checkpoints[MAXCP][3] =
{
	{-299.1656,1357.1959,14.4076},
	{-299.5701,1772.0497,8.9998},
	{-408.5639,1969.5201,-6.7579},
	{-581.1505,1980.0231,-20.4502},
	{-804.6606,1918.9923,-20.4443},
	{-781.6433,1876.2695,-20.4454},
	{-840.5950,1572.8840,-20.4490},
	{-1035.1525,1761.9767,-1.7328},
	{-1087.8781,1875.4382,15.4096},
	{-1033.4203,1882.9033,15.4858},
	{-796.5846,1587.9492,11.5936},
	{-787.7514,1412.2202,20.5680},
	{-814.8893,1354.7382,20.9545},
	{-959.9572,1064.8563,35.6028},
	{-1063.5172,771.6789,25.6051},
	{-1063.6122,601.8050,25.7062},
	{-1063.8065,468.1730,25.6063},
	{-1055.2775,411.3179,25.6062},
	{-1043.0914,503.9740,25.6065},
	{-1042.6262,604.5204,25.7551},
	{-1042.7869,700.5965,25.6048},
	{-1042.9364,750.7055,25.6176},
	{-1013.3928,758.2021,21.6558},
	{-977.9301,727.0694,15.6221},
	{-978.1849,635.0269,15.4923},
	{-978.4687,588.4636,27.4788},
	{0.0, 0.0, 0.0}
};

new minutes[MAX_PLAYERS];
new seconds[MAX_PLAYERS];
new playercheck[MAX_PLAYERS];

new timesfinished = 0; 
new respawn[MAX_PLAYERS]; 
new raceon = 0;

new setracestart = 0;

new playerinrace[MAX_PLAYERS]; 

new rcount = 0; 

new str[128],
	PlayerName[128];
	
new gRoundTimer,
	gRoundTime = 600000; // 10 minutes
	
new Text:BarTD[MAX_PLAYERS];
new UpdateTimer[MAX_PLAYERS];
new SecondTimer[MAX_PLAYERS];
	
main()
{
	print("*************************");
	print("* GTA:U MultiPlayer     *");
	print("* Liberty City Racing   *");
	print("* by Westie & Andre9977 *");
}

public OnGameModeInit()
{
    SetGameModeText("GTA:U Race");

    ShowPlayerMarkers(1);
    ShowNameTags(1);

    AddPlayerClass(36,2105.7695,-361.3560,10.6444,133.2551,-1,-1,-1,-1,-1,-1);
    AddPlayerClass(37,2105.7695,-361.3560,10.6444,133.2551,-1,-1,-1,-1,-1,-1);

	AddStaticVehicle(541, -290.1912, 1313.4010, 14.4064, 0.0, -1, -1); //
	AddStaticVehicle(541, -292.6591, 1313.4010, 14.4064, 0.0, -1, -1); //
	AddStaticVehicle(541, -295.2202, 1313.4010, 14.4064, 0.0, -1, -1); //
	AddStaticVehicle(541, -297.6768, 1313.4010, 14.4064, 0.0, -1, -1); //
	AddStaticVehicle(541, -300.1947, 1313.4010, 14.4064, 0.0, -1, -1); //
	AddStaticVehicle(541, -302.7277, 1313.4010, 14.4064, 0.0, -1, -1); //
	AddStaticVehicle(541, -305.2753, 1313.4010, 14.4064, 0.0, -1, -1); //
	AddStaticVehicle(541, -307.7375, 1313.4010, 14.4064, 0.0, -1, -1); //

	AddStaticVehicle(541, -290.1912, 1304.4010, 14.4064, 0.0, -1, -1); //
	AddStaticVehicle(541, -292.6591, 1304.4010, 14.4064, 0.0, -1, -1); //
	AddStaticVehicle(541, -295.2202, 1304.4010, 14.4064, 0.0, -1, -1); //
	AddStaticVehicle(541, -297.6768, 1304.4010, 14.4064, 0.0, -1, -1); //
	AddStaticVehicle(541, -300.1947, 1304.4010, 14.4064, 0.0, -1, -1); //
	AddStaticVehicle(541, -302.7277, 1304.4010, 14.4064, 0.0, -1, -1); //
	AddStaticVehicle(541, -305.2753, 1304.4010, 14.4064, 0.0, -1, -1); //
	AddStaticVehicle(541, -307.7375, 1304.4010, 14.4064, 0.0, -1, -1); //

	AddStaticVehicle(541, -290.1912, 1295.4010, 14.4064, 0.0, -1, -1); //
	AddStaticVehicle(541, -292.6591, 1295.4010, 14.4064, 0.0, -1, -1); //
	AddStaticVehicle(541, -295.2202, 1295.4010, 14.4064, 0.0, -1, -1); //
	AddStaticVehicle(541, -297.6768, 1295.4010, 14.4064, 0.0, -1, -1); //
	AddStaticVehicle(541, -300.1947, 1295.4010, 14.4064, 0.0, -1, -1); //
	AddStaticVehicle(541, -302.7277, 1295.4010, 14.4064, 0.0, -1, -1); //
	AddStaticVehicle(541, -305.2753, 1295.4010, 14.4064, 0.0, -1, -1); //
	AddStaticVehicle(541, -307.7375, 1295.4010, 14.4064, 0.0, -1, -1); //

    gRoundTimer = SetTimer("DefenceWin", gRoundTime, false);
    
    SetTimer("BeginRace", 1000, 1);
	return 1;
}

public TimeIsOver()
{
    GameTextForAll("~r~Time's up!", 5000, 5);
    SetTimer("ChangeMode", 3000, false);
    
}

public LastRacer()
{
	KillTimer(gRoundTimer);
	GameTextForAll("~r~Race is over!", 5000, 5);
	SetTimer("ChangeMode", 3000, false);
}

public ChangeMode()
{
    SendRconCommand("changemode /GTAU/RACE.amx");
}

public OnPlayerConnect(playerid)
{
	GetPlayerName(playerid, PlayerName, sizeof(PlayerName));
	format(str, sizeof(str), "SERVER: %s(id:%i) has joined the server.", PlayerName, playerid);
	SendClientMessageToAll(COLOR_GREY, str);
	
	SendClientMessage(playerid, COLOR_GREEN, "WELCOME! This is the GTA:United beta test on SA-MP!");
	SendClientMessage(playerid, COLOR_GREEN, "BETA GM: GTA: United Race (by Westie & Andre9977)");
    GameTextForPlayer(playerid,"~w~GTA United SA-MP: ~r~GTA:U Race",5000,5);
    
    SetVehicleToRespawn(playerid + 1);
    
    BarTD[playerid] = TextDrawCreate(163.000000,361.000000,"Please wait for the race to begin.");
	TextDrawAlignment(BarTD[playerid],0);
	TextDrawBackgroundColor(BarTD[playerid],0x00000099);
	TextDrawFont(BarTD[playerid],1);
	TextDrawLetterSize(BarTD[playerid],0.399999,1.300000);
	TextDrawColor(BarTD[playerid],0xffffffff);
	TextDrawSetOutline(BarTD[playerid],1);
	TextDrawSetProportional(BarTD[playerid],1);
	
    return 1;
}

public OnPlayerDisconnect(playerid, reason)
{
	KillTimer(UpdateTimer[playerid]);
	KillTimer(SecondTimer[playerid]);
	
	minutes[playerid] = 0;
	seconds[playerid] = 0;
	playercheck[playerid] = 0;
	
	TextDrawHideForPlayer(playerid, BarTD[playerid]);
	
    GetPlayerName(playerid, PlayerName, sizeof(PlayerName));
	switch(reason)
	{
	    case 0: format(str, sizeof(str), "crashed");
	    case 1: format(str, sizeof(str), "left");
	    case 2: format(str, sizeof(str), "got kicked / banned");
	}
    format(str, sizeof(str), "SERVER: %s(id:%i) has %s.", PlayerName, playerid, str);
	SendClientMessage(playerid, COLOR_GREY, str);
	return 1;
}

public OnPlayerCommandText(playerid, cmdtext[])
{
    return 0;
}

public OnPlayerSpawn(playerid)
{
    TextDrawShowForPlayer(playerid, BarTD[playerid]);
    
    PlayerPlaySound(playerid, 1186, 0, 0, 0);
	PlayerPlaySound(playerid, 1150, 0, 0, 0);

	SetPlayerColor(playerid, COLOR_GREEN);
	SetPlayerInterior(playerid, 0);
	
    GivePlayerMoney(playerid, 5000);
    
    if(respawn[playerid] == 0)
	{
		playerinrace[playerid] = 1;
		playercheck[playerid] = 0;

		PutPlayerInVehicle(playerid, playerid + 1, 0);

		SetCameraBehindPlayer(playerid);

		if(raceon == 0)
		{

			TogglePlayerControllable(playerid,0);
			GameTextForPlayer(playerid,"~w~Starting in:~g~ 5 secs", 4000, 5);
			SetTimer("BeginRace2", 5000, false);

		}
		else
		{

			GameTextForPlayer(playerid,"~r~GO, GO, GO!", 2000, 5);
			TogglePlayerControllable(playerid, 1);
			SetPlayerCheckpoint(playerid, checkpoints[0][0], checkpoints[0][1], checkpoints[0][2], 8);

		}
	}
    return 1;
}

public OnPlayerDeath(playerid, killerid, reason)
{
    TextDrawShowForPlayer(playerid, BarTD[playerid]);
    
    SetVehicleToRespawn(playerid + 1);
}

public OnPlayerEnterCheckpoint(playerid)
{
	UpdateTD(playerid);
	playercheck[playerid] = playercheck[playerid] + 1;

	if(playercheck[playerid] >= 1 && playercheck[playerid] <= MAXCP - 2)
	{
		DisablePlayerCheckpoint(playerid);
		SetPlayerCheckpoint(playerid, checkpoints[playercheck[playerid]][0], checkpoints[playercheck[playerid]][1], checkpoints[playercheck[playerid]][2],7.0);
		format(str, sizeof(str), "%d - %d", playercheck[playerid], MAXCP - 1);
		GameTextForPlayer(playerid, str, 2000, 6);
	}

	if(playercheck[playerid] == MAXCP - 1)
	{

		KillTimer(UpdateTimer[playerid]);
		KillTimer(SecondTimer[playerid]);
				
		timesfinished ++;

		if(timesfinished == 15 || timesfinished > 15)
		{
			LastRacer();
		}

		DisablePlayerCheckpoint(playerid);

		GetPlayerName(playerid, PlayerName, sizeof(PlayerName));

		new pos[10];
		if(timesfinished == 1) pos = "1st";
		if(timesfinished == 2) pos = "2nd";
		if(timesfinished == 3) pos = "3rd";
		if(timesfinished == 4) pos = "4th";
		if(timesfinished == 5) pos = "5th";
		if(timesfinished == 6) pos = "6th";
		if(timesfinished == 7) pos = "7th";
		if(timesfinished == 8) pos = "8th";
		if(timesfinished == 9) pos = "9th";
		if(timesfinished == 10) pos = "10th";
		if(timesfinished == 11) pos = "11th";
		if(timesfinished == 12) pos = "12th";
		if(timesfinished == 13) pos = "13th";
		if(timesfinished == 14) pos = "14th";
		if(timesfinished == 15) pos = "15th";

        format(str, sizeof(str), "~p~Finished in ~g~%d minutes ~p~and ~g~%d ~p~seconds as ~y~%s", minutes[playerid], seconds[playerid], pos);
		TextDrawSetString(BarTD[playerid], str);
		
		format(str,sizeof(str),"~r~%s(%i) ~g~finished %s!~n~", PlayerName, playerid, pos);
		GameTextForAll(str, 5000, 3);
		format(str, sizeof(str),"** %s (id:%i) finished %s (time: %d minutes, %d seconds)", PlayerName, playerid, pos, minutes[playerid], seconds[playerid]);
		SendClientMessageToAll(0x00FF00FF, str);
		SendClientMessage(playerid, COLOR_WHITE, "Please wait until the race finishes.");

		respawn[playerid] = 1;
	}
	return 1;
}

public OnPlayerRequestClass(playerid, classid)
{
    GameTextForPlayer(playerid, "~g~Racers", 2000, 5);
    SetupPlayerForClassSelection(playerid);
    return 1;
}

public SetupPlayerForClassSelection(playerid)
{
    SetPlayerInterior(playerid, 0);
    SetPlayerPos(playerid, 2079.4976, -365.7190, 9.0355);
    SetPlayerFacingAngle(playerid, 283.0);
    SetPlayerCameraPos(playerid, 2090.0, -364.3, 11.5);
    SetPlayerCameraLookAt(playerid, 2079.4976, -365.7190, 9.0355);
}

public BeginRace2()
{
	setracestart = 1;
	BeginRace();
	return 1;
}

public BeginRace()
{
	if(setracestart == 1)
	{
		for(new i = 0; i < GetMaxPlayers(); i++)
  		{
	        if(playerinrace[i] == 1 && rcount == 0)
			{
		        GameTextForPlayer(i,"~w~Get ready!",1000,4);
		        PlayerPlaySound(i, 1052, 0, 0, 0);
		        print("RACE: 4");
		        
		        format(str, sizeof(str), "~p~Get ready to race!");
				TextDrawSetString(BarTD[i], str);
			}
	        if(playerinrace[i] == 1 && rcount == 1)
			{
		        GameTextForPlayer(i,"~g~3",1000,3);
		        PlayerPlaySound(i, 1053, 0, 0, 0);
		        print("RACE: 3");
		        
		        format(str, sizeof(str), "~p~3");
				TextDrawSetString(BarTD[i], str);
			}
	        if(playerinrace[i] == 1 && rcount == 2)
			{
		        GameTextForPlayer(i,"~g~2",1000,3);
		        PlayerPlaySound(i, 1053, 0, 0, 0);
		        print("RACE: 2");
		        
		        format(str, sizeof(str), "~p~2");
				TextDrawSetString(BarTD[i], str);
			}
	        if(playerinrace[i] == 1 && rcount == 3)
			{
		        GameTextForPlayer(i,"~g~1",1000,3);
		        PlayerPlaySound(i, 1053, 0, 0, 0);
				print("RACE: 1");
				
				format(str, sizeof(str), "~p~1");
				TextDrawSetString(BarTD[i], str);
			}
	        if(playerinrace[i] == 1 && rcount == 4)
			{
		        GameTextForPlayer(i,"~r~Let's roll!", 2000, 3);
		        PlayerPlaySound(i, 1085, 0, 0, 0);
		        TogglePlayerControllable(i, 1);
		        SetPlayerCheckpoint(i, checkpoints[0][0], checkpoints[0][1], checkpoints[0][2], 8);

                format(str, sizeof(str), "~r~Go, Go, Go!");
				TextDrawSetString(BarTD[i], str);
				
				SecondTimer[i] = SetTimerEx("CountSeconds", 910, true, "i", i);
				UpdateTimer[i] = SetTimerEx("UpdateTD", 910, true, "i", i);
				print("RACE: started");
		        raceon = 1;
			}
		}

		rcount = rcount + 1;
	}

	return 1;
}

forward UpdateTD(playerid);
public UpdateTD(playerid)
{
	for(new i = 0; i < GetMaxPlayers(); i++)
	{
		format(str, sizeof(str), "~w~Time: ~r~%d ~y~minutes~w~, ~r~%d ~w~~y~seconds ~w~Checkpoints: ~y~%d~w~/~g~%d", minutes[i], seconds[i], playercheck[i], MAXCP-1);
		TextDrawSetString(BarTD[playerid], str);
	}
}

forward CountSeconds(playerid);
public CountSeconds(playerid)
{
	seconds[playerid] = seconds[playerid] + 1;
	if(seconds[playerid] == 60)
	{
	    minutes[playerid] = minutes[playerid] + 1;
	    seconds[playerid] = 0;
	}
	return true;
}
