//////////////////////////////////////////////////////////////////
//                                                              //
//             |    -------------------------    |              //
//	           |        Vice City Madness        |              //
//      	   |    -------------------------    |              //
//	           |         By: MaTrIx4057          |              //
//                                                              //
//////////////////////////////////////////////////////////////////
#include <a_samp>

new gRoundTime = 0;
//new gRoundTime = 900000;					// Round time - 15 mins
forward GameModeExitFunc();

enum PlInfo
{
	Float:PlX,
	Float:PlY,
	Float:PlZ,
	Float:PlAngle
}

new Float:gRandomSpawns[][PlInfo] =
{
	{1638.8336, -1523.5890, 31.3884, 270.3613},
	{1608.3215, -1523.5559, 34.5056, 263.3820},
	{1682.3846, -1532.1619, 28.0316, 269.7740},
	{1673.8575, -1526.5203, 22.0240, 182.0004},
	{1677.4874, -1529.8733, 6.0621, 11.6881},
	{1621.5663, -1544.5767, 4.8223, 1.3541},
	{1619.4313, -1605.3593, 2.4225, 272.9932},
	{1621.7556, -1556.2711, 11.7433, 278.2573},
	{1757.2684, -1532.1719, 7.4004, 90.8429},
	{1591.3768, -1539.8997, 6.0802, 357.0534},
	{1530.3267, -1527.5645, 7.3707, 269.6559},
	{1664.0740, -1514.4457, 14.0383, 359.8968},
	{1622.5920, -1531.2666, 14.0308, 87.5056},
	{1597.4119, -1515.7054, 14.0326, 89.7616},
	{1621.3854, -1546.6104, 20.2896, 177.1591},
	{1616.2467, -1508.1782, 22.0308, 270.7840},
	{1663.9058, -1519.0028, 22.0176, 359.5208},
	{1598.0531, -1491.9219, 11.7430, 92.7697},
	{1565.4563, -1501.7019, 4.7952, 89.9264},
	{1692.2904, -1501.4099, 4.7912, 266.8128}

};

public GameModeExitFunc()
{
	GameModeExit( );
}

main()
{
	print("====================================");
	print("|                                  |");
	print("|     -------------------------    |");
	print("|         Vice City Madness        |");
	print("|     -------------------------    |");
	print("|          By: MaTrIx4057          |");
	print("|                                  |");
	print("|                                  |");
	print("====================================");
}

public OnGameModeInit()
{
	SetGameModeText("VC Madness");
	ShowNameTags(0);
	ShowPlayerMarkers(0);
	SendRconCommand("mapname Vice City");

	AddPlayerClass(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
	
	AddStaticPickup(362, 2, 1697.6797, -1533.2472, 6.6511);
	AddStaticPickup(362, 2, 1524.4512, -1543.8158, 7.3113);
	AddStaticPickup(360, 2, 1747.0133, -1550.2926, 6.6955);
	AddStaticPickup(360, 2, 1497.7896, -1547.6919, 6.6450);
	AddStaticPickup(359, 2, 1621.5248, -1556.7627, 3.6192);
	AddStaticPickup(359, 2, 1642.5647, -1494.4312, 7.2243);
	
	if(gRoundTime > 0) SetTimer("GameModeExitFunc", gRoundTime, 0);
	return 1;

}

public OnPlayerRequestClass(playerid, classid)
{
	SetPlayerPos(playerid, 1621.4536, -1503.7506, 14.0368);
	SetPlayerFacingAngle(playerid, 10);
	SetPlayerCameraPos(playerid, 1621.2710, -1498.7734, 12.5604+3);
	SetPlayerCameraLookAt(playerid, 1621.4536, -1503.7506, 14.0368);
	return 1;
}

public OnPlayerRequestSpawn(playerid)
{
	ResetSpawnInfo(playerid);
	return 1;
}

public OnPlayerDeath(playerid, killerid, reason)
{
	SendDeathMessage(killerid, playerid, reason);
	SetPlayerScore(killerid, GetPlayerScore(killerid) + 1);
	ResetSpawnInfo(playerid);
	return 1;
}

ResetSpawnInfo(playerid)
{
	new rand = random(sizeof(gRandomSpawns));
	SetSpawnInfo(playerid, 255, 0, gRandomSpawns[rand][PlX], gRandomSpawns[rand][PlY], gRandomSpawns[rand][PlZ], gRandomSpawns[rand][PlAngle], 38, 500, 0, 0, 0, 0);
}
