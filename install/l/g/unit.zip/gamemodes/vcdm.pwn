#include <a_samp>
#include <core>
#include <float>

#pragma tabsize 0

#define COLOR_GREY 0xAFAFAFAA
#define COLOR_GREEN 0x33AA33AA
#define COLOR_RED 0xAA3333AA
#define COLOR_YELLOW 0xFFFF00AA
#define COLOR_WHITE 0xFFFFFFAA
#define PocketMoney 50000 // Amount player recieves on spawn.
#define INACTIVE_PLAYER_ID INVALID_PLAYER_ID
#define GIVECASH_DELAY 5000 // Time in ms between /givecash commands.

#define NUMVALUES 4

forward MoneyGrubScoreUpdate();
forward Givecashdelaytimer(playerid);
forward SetPlayerRandomSpawn(playerid);
forward SetupPlayerForClassSelection(playerid);
forward GameModeExitFunc();
forward SendPlayerFormattedText(playerid, const str[], define);
forward public SendAllFormattedText(playerid, const str[], define);

//------------------------------------------------------------------------------------------------------

new CashScoreOld;
new iSpawnSet[MAX_PLAYERS];

new Float:gRandomPlayerSpawns[23][3] = {
{2100.1741,-696.6563,16.2319},
{2532.0942,-862.6500,5.6632},
{2492.5464,-1030.0674,5.9461},
{2397.9719,-1421.0092,6.2151},
{2197.8582,-1431.4828,5.5276},
{2259.4214,-1182.8060,5.5365},
{1115.6359,-1420.6652,7.5683},
{1273.4032,-2418.2153,5.7194},
{1362.5302,-2435.8232,8.1496},
{2197.8582,-1431.4828,5.5276},
{2197.8582,-1431.4828,5.5276},
{2197.8582,-1431.4828,5.5276},
{2492.5464,-1030.0674,5.9461},
{2492.5464,-1030.0674,5.9461},
{2492.5464,-1030.0674,5.9461},
{2492.5464,-1030.0674,5.9461},
{2197.8582,-1431.4828,5.5276},
{2197.8582,-1431.4828,5.5276},
{2197.8582,-1431.4828,5.5276},
{2197.8582,-1431.4828,5.5276},
{2197.8582,-1431.4828,5.5276},
{2492.5464,-1030.0674,5.9461},
{2492.5464,-1030.0674,5.9461}
};

new Float:gCopPlayerSpawns[2][3] = {
{2397.9006,-1421.1266,6.2151},
{2397.9006,-1421.1266,6.2151}
};

//Round code stolen from mike's Manhunt :P
//new gRoundTime = 3600000;                   // Round time - 1 hour
//new gRoundTime = 1200000;					// Round time - 20 mins
//new gRoundTime = 900000;					// Round time - 15 mins
//new gRoundTime = 600000;					// Round time - 10 mins
//new gRoundTime = 300000;					// Round time - 5 mins
//new gRoundTime = 120000;					// Round time - 2 mins
//new gRoundTime = 60000;					// Round time - 1 min

new gActivePlayers[MAX_PLAYERS];
new gLastGaveCash[MAX_PLAYERS];

//------------------------------------------------------------------------------------------------------

main()
{
		print("\n----------------------------------");
		print("  Running VCDM ~MoneyGrub\n		   ");
		print("      Original Coded By			   ");
		print("     Jax changed by IceCube	       ");
		print("----------------------------------\n");
}

//------------------------------------------------------------------------------------------------------

public MoneyGrubScoreUpdate()
{
	new CashScore;
	new name[MAX_PLAYER_NAME];
	//new string[256];
	for(new i=0; i<MAX_PLAYERS; i++)
	{
		if (IsPlayerConnected(i))
		{
			GetPlayerName(i, name, sizeof(name));
   			CashScore = GetPlayerMoney(i);
			SetPlayerScore(i, CashScore);
			if (CashScore > CashScoreOld)
			{
				CashScoreOld = CashScore;
				//format(string, sizeof(string), "$$$ %s is now in the lead $$$", name);
				//SendClientMessageToAll(COLOR_YELLOW, string);
			}
		}
	}
}

//------------------------------------------------------------------------------------------------------

/*public GrubModeReset()
{
	for(new i=0; i<MAX_PLAYERS; i++)
	{
		if (IsPlayerConnected(i))
		{
			SetPlayerScore(i, PocketMoney);
			SetPlayerRandomSpawn(i, classid);
		}
	}

}*/

//------------------------------------------------------------------------------------------------------

public OnPlayerConnect(playerid)
{
	GameTextForPlayer(playerid,"~w~SA-MP: ~r~Vice City ~g~MoneyGrub",5000,5);
	SendPlayerFormattedText(playerid, "Welcome to Vice City MoneyGrub, For help type /help.", 0);
	gActivePlayers[playerid]++;
	gLastGaveCash[playerid] = GetTickCount();
	return 1;
}

//------------------------------------------------------------------------------------------------------
public OnPlayerDisconnect(playerid)
{
	gActivePlayers[playerid]--;
}
//------------------------------------------------------------------------------------------------------

public OnPlayerCommandText(playerid, cmdtext[])
{
	new string[256];
	new playermoney;
	new sendername[MAX_PLAYER_NAME];
	new giveplayer[MAX_PLAYER_NAME];
	new cmd[256];
	new giveplayerid, moneys, idx;

	cmd = strtok(cmdtext, idx);

	if(strcmp(cmd, "/help", true) == 0) {
		SendPlayerFormattedText(playerid,"Vice City Deathmatch: Money Grub Coded By Jax, IceCube and the SA-MP Team.",0);
		SendPlayerFormattedText(playerid,"Type: /objective : to find out what to do in this gamemode.",0);
		SendPlayerFormattedText(playerid,"Type: /givecash [playerid] [money-amount] to send money to other players.",0);
		SendPlayerFormattedText(playerid,"Type: /tips : to see some tips from the creator of the gamemode.", 0);
    return 1;
	}
	if(strcmp(cmd, "/objective", true) == 0) {
		SendPlayerFormattedText(playerid,"This gamemode is faily open, there's no specific win / endgame conditions to meet.",0);
		SendPlayerFormattedText(playerid,"In VCDM:Money Grub, when you kill a player, you will receive whatever money they have.",0);
		SendPlayerFormattedText(playerid,"Consequently, if you have lots of money, and you die, your killer gets your cash.",0);
		SendPlayerFormattedText(playerid,"However, you're not forced to kill players for money, you can always gamble in the", 0);
		SendPlayerFormattedText(playerid,"Casino's.", 0);
    return 1;
	}
	if(strcmp(cmd, "/tips", true) == 0) {
		SendPlayerFormattedText(playerid,"Spawning with just a desert eagle might sound lame, however the idea of this",0);
		SendPlayerFormattedText(playerid,"gamemode is to get some cash, get better guns, then go after whoever has the",0);
		SendPlayerFormattedText(playerid,"most cash. Once you've got the most cash, the idea is to stay alive(with the",0);
		SendPlayerFormattedText(playerid,"cash intact)until the game ends, simple right ?", 0);
    return 1;
	}

 	if(strcmp(cmd, "/givecash", true) == 0) {
	    new tmp[256];
		tmp = strtok(cmdtext, idx);

		if(!strlen(tmp)) {
			SendClientMessage(playerid, COLOR_WHITE, "USAGE: /givecash [playerid] [amount]");
			return 1;
		}
		giveplayerid = strval(tmp);

		tmp = strtok(cmdtext, idx);
		if(!strlen(tmp)) {
			SendClientMessage(playerid, COLOR_WHITE, "USAGE: /givecash [playerid] [amount]");
			return 1;
		}
 		moneys = strval(tmp);

		//printf("givecash_command: %d %d",giveplayerid,moneys);


		if (IsPlayerConnected(giveplayerid)) {
			GetPlayerName(giveplayerid, giveplayer, sizeof(giveplayer));
			GetPlayerName(playerid, sendername, sizeof(sendername));
			playermoney = GetPlayerMoney(playerid);
			if (moneys > 0 && playermoney >= moneys) {
				GivePlayerMoney(playerid, (0 - moneys));
				GivePlayerMoney(giveplayerid, moneys);
				format(string, sizeof(string), "You have sent %s(player: %d), $%d.", giveplayer,giveplayerid, moneys);
				SendClientMessage(playerid, COLOR_YELLOW, string);
				format(string, sizeof(string), "You have recieved $%d from %s(player: %d).", moneys, sendername, playerid);
				SendClientMessage(giveplayerid, COLOR_YELLOW, string);
				printf("%s(playerid:%d) has transfered %d to %s(playerid:%d)",sendername, playerid, moneys, giveplayer, giveplayerid);
			}
			else {
				SendClientMessage(playerid, COLOR_YELLOW, "Invalid transaction amount.");
			}
		}
		else {
				format(string, sizeof(string), "%d is not an active player.", giveplayerid);
				SendClientMessage(playerid, COLOR_YELLOW, string);
			}
		return 1;
	}

	// PROCESS OTHER COMMANDS


	return 0;
}

//------------------------------------------------------------------------------------------------------

public OnPlayerSpawn(playerid)
{
	GivePlayerMoney(playerid, PocketMoney);
	SetPlayerInterior(playerid,0);
	SetPlayerRandomSpawn(playerid);
	TogglePlayerClock(playerid,1);
	return 1;
}

public SetPlayerRandomSpawn(playerid)
{
	if (iSpawnSet[playerid] == 1)
	{
		new rand = random(sizeof(gCopPlayerSpawns));
		SetPlayerPos(playerid, gCopPlayerSpawns[rand][0], gCopPlayerSpawns[rand][1], gCopPlayerSpawns[rand][2]); // Warp the player
		SetPlayerFacingAngle(playerid, 270.0);
    }
    else if (iSpawnSet[playerid] == 0)
    {
		new rand = random(sizeof(gRandomPlayerSpawns));
		SetPlayerPos(playerid, gRandomPlayerSpawns[rand][0], gRandomPlayerSpawns[rand][1], gRandomPlayerSpawns[rand][2]); // Warp the player
	}
	return 1;
}

//------------------------------------------------------------------------------------------------------

public OnPlayerDeath(playerid, killerid, reason)
{
    new playercash;
	if(killerid == INVALID_PLAYER_ID) {
        SendDeathMessage(INVALID_PLAYER_ID,playerid,reason);
        ResetPlayerMoney(playerid);
	} else {
	    	SendDeathMessage(killerid,playerid,reason);
			SetPlayerScore(killerid,GetPlayerScore(killerid)+1);
			playercash = GetPlayerMoney(playerid);
			if (playercash > 0)  {
				GivePlayerMoney(killerid, playercash);
				ResetPlayerMoney(playerid);
			}
			else
			{
			}
     	}
 	return 1;
}

/* public OnPlayerDeath(playerid, killerid, reason)
{   haxed by teh mike
	new name[MAX_PLAYER_NAME];
	new string[256];
	new deathreason[20];
	new playercash;
	GetPlayerName(playerid, name, sizeof(name));
	GetWeaponName(reason, deathreason, 20);
	if (killerid == INVALID_PLAYER_ID) {
	    switch (reason) {
			case WEAPON_DROWN:
			{
                format(string, sizeof(string), "*** %s drowned.)", name);
			}
			default:
			{
			    if (strlen(deathreason) > 0) {
					format(string, sizeof(string), "*** %s died. (%s)", name, deathreason);
				} else {
				    format(string, sizeof(string), "*** %s died.", name);
				}
			}
		}
	}
	else {
	new killer[MAX_PLAYER_NAME];
	GetPlayerName(killerid, killer, sizeof(killer));
	if (strlen(deathreason) > 0) {
		format(string, sizeof(string), "*** %s killed %s. (%s)", killer, name, deathreason);
		} else {
				format(string, sizeof(string), "*** %s killed %s.", killer, name);
			}
		}
	SendClientMessageToAll(COLOR_RED, string);
		{
		playercash = GetPlayerMoney(playerid);
		if (playercash > 0)
		{
			GivePlayerMoney(killerid, playercash);
			ResetPlayerMoney(playerid);
		}
		else
		{
		}
	}
 	return 1;
}*/

//------------------------------------------------------------------------------------------------------

public OnPlayerRequestClass(playerid, classid)
{
	iSpawnSet[playerid] = 0;
	SetupPlayerForClassSelection(playerid);
	return 1;
}

public SetupPlayerForClassSelection(playerid)
{
 	SetPlayerInterior(playerid,14);
	SetPlayerPos(playerid,258.4893,-41.4008,1002.0234);
	SetPlayerFacingAngle(playerid, 270.0);
	SetPlayerCameraPos(playerid,256.0815,-43.0475,1004.0234);
	SetPlayerCameraLookAt(playerid,258.4893,-41.4008,1002.0234);
}

public GameModeExitFunc()
{
	GameModeExit();
}

public OnGameModeInit()
{
	SetGameModeText("Vice City's VC~MG");

	ShowPlayerMarkers(1);
	ShowNameTags(1);

	// 0.2.2 specific stuff
	//DisableInteriorEnterExits();
	//SetNameTagDrawDistance(10.0);
	//EnableStuntBonusForAll(0);

	/* Was testing the new pickup limit.
	new Float:pickX=2040.0520;
	new Float:pickY=1319.2799;
	new Float:pickZ=10.3779;
	new x=0;
	while(x!=400) {
		AddStaticPickup(1272,2,pickX,pickY,pickZ);
		pickY+=1.0;
		x++;
	}*/

	// Player Class's
	AddPlayerClass(265,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(266,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(267,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(268,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(269,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(270,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(271,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(272,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);

	AddPlayerClass(280,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(281,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(282,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(283,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(284,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(285,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(286,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(287,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);

	AddPlayerClass(254,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(255,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(256,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(257,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(258,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(259,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(260,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(261,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(262,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(263,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(264,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(274,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(275,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(276,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);

	AddPlayerClass(1,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(2,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(290,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(291,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(292,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(293,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(294,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(295,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(296,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(297,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(298,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
    AddPlayerClass(299,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);

	AddPlayerClass(277,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(278,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(279,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(288,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(47,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(48,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(49,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(50,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(51,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(52,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(53,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(54,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(55,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(56,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(57,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(58,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(59,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(60,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(61,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(62,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(63,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(64,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(66,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(67,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(68,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(69,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(70,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(71,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(72,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(73,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(75,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(76,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(78,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(79,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(80,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(81,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(82,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(83,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(84,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(85,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(87,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(88,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(89,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(91,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(92,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(93,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(95,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(96,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(97,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(98,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(99,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(100,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(101,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(102,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(103,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(104,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(105,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(106,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(107,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(108,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(109,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(110,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(111,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(112,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(113,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(114,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(115,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(116,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(117,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(118,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(120,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(121,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(122,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(123,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(124,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(125,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(126,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(127,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(128,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(129,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(131,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(133,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(134,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(135,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(136,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(137,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(138,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(139,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(140,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(141,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(142,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(143,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(144,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(145,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(146,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(147,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(148,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(150,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(151,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(152,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(153,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(154,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(155,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(156,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(157,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(158,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(159,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(160,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(161,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(162,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(163,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(164,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(165,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(166,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(167,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(168,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(169,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(170,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(171,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(172,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(173,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(174,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(175,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(176,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(177,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(178,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(179,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(180,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(181,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(182,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(183,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(184,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(185,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(186,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(187,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(188,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(189,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(190,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(191,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(192,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(193,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(194,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(195,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(196,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(197,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(198,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(199,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(200,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(201,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(202,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(203,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(204,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(205,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(206,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(207,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(209,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(210,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(211,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(212,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(213,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(214,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(215,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(216,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(217,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(218,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(219,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(220,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(221,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(222,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(223,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(224,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(225,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(226,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(227,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(228,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(229,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(230,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(231,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(232,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(233,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(234,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(235,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(236,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(237,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(238,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(239,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(240,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(241,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(242,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(243,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(244,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(245,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(246,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(247,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(248,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(249,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(250,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(251,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);
	AddPlayerClass(253,2100.1741,-696.6563,16.2319,201.8363,0,0,0,0,0,0);

	return 1;
}

public SendPlayerFormattedText(playerid, const str[], define)
{
	new tmpbuf[256];
	format(tmpbuf, sizeof(tmpbuf), str, define);
	SendClientMessage(playerid, 0xFF004040, tmpbuf);
}

public SendAllFormattedText(playerid, const str[], define)
{
	new tmpbuf[256];
	format(tmpbuf, sizeof(tmpbuf), str, define);
	SendClientMessageToAll(0xFFFF00AA, tmpbuf);
}

strtok(const string[], &index)
{
	new length = strlen(string);
	while ((index < length) && (string[index] <= ' '))
	{
		index++;
	}

	new offset = index;
	new result[20];
	while ((index < length) && (string[index] > ' ') && ((index - offset) < (sizeof(result) - 1)))
	{
		result[index - offset] = string[index];
		index++;
	}
	result[index - offset] = EOS;
	return result;
}
