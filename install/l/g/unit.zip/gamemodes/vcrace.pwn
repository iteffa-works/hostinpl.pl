#include <a_samp>

#define COLOR_YELLOW 0xFFFF00AA
#define COLOR_WHITE 0xFFFFFFAA
#define INACTIVE_PLAYER_ID INVALID_PLAYER_ID

#define COLOR_GREY 			0xAFAFAFAA
#define COLOR_PURPLE 		0xC2A2DAAA
#define COLOR_YELLOW 		0xFFFF00AA
#define COLOR_WHITE 		0xFFFFFFAA
#define COLOR_DBLUE 		0x2641FEAA
#define COLOR_BLUE 			0x33AAFFFF
#define COLOR_GREEN 		0x33AA33AA
#define COLOR_ORANGE 		0xFF9900AA
#define COLOR_GREY 			0xAFAFAFAA
#define COLOR_GREEN 		0x33AA33AA
#define COLOR_RED 			0xAA3333AA
#define COLOR_LIGHTRED 		0xFF6347AA
#define COLOR_LIGHTBLUE 	0x33CCFFAA
#define COLOR_LIGHTGREEN 	0x9ACD32AA
#define COLOR_YELLOW 		0xFFFF00AA
#define COLOR_YELLOW2 		0xF5DEB3AA
#define COLOR_WHITE 		0xFFFFFFAA
#define COLOR_FADE1 		0xE6E6E6E6
#define COLOR_FADE2 		0xC8C8C8C8
#define COLOR_FADE3 		0xAAAAAAAA
#define COLOR_FADE4 		0x8C8C8C8C
#define COLOR_FADE5 		0x6E6E6E6E
#define COLOR_PURPLE 		0xC2A2DAAA
#define COLOR_DBLUE 		0x2641FEAA
#define COLOR_CYAN 			0x00FFFFAA
#define COLOR_SYSTEM 		0xEFEFF7AA

forward BeginRace2();
forward BeginRace();
forward GameModeExitFunc();
forward DefenceWin();

forward TimeIsOver();
forward LastRacer();
forward ChangeMode();

forward SetupPlayerForClassSelection(playerid);

#define MAXCP 29
new Float:checkpoints[MAXCP][3] =
{
	{2313.9358, 46.2032, 6.5545},
	{2271.5073, 185.3871, 15.2699},
	{2247.8145, 268.8354, 11.6237},
	{2307.1494, 334.2380, 11.3951},
	{2503.9712, 321.9962, 11.3466},
	{2500.8984, 191.7548, 10.3615},
	{2549.2295, -40.3622, 9.3696},
	{2537.3799, -293.8120, 5.3034},
	{2508.0974, -620.9896, 5.0677},
	{2494.2310, -925.4554, 5.0670},
	{2506.1545, -1053.7174, 4.7277},
	{2482.6443, -1158.4512, 5.6755},
	{2434.6726, -1336.9369, 4.3707},
	{2346.0596, -1411.8818, 4.1094},
	{2217.0212, -1400.0548, 5.9634},
	{2185.4028, -1368.7523, 5.0523},
	{2220.2288, -1233.6648, 6.4488},
	{2319.0513, -1010.4006, 3.9220},
	{2370.5459, -938.6907, 5.5002},
	{2418.4519, -895.8791, 5.3475},
	{2313.1858, -745.1904, 5.3936},
	{2313.2341, -705.9974, 5.6052},
	{2335.2468, -629.8867, 5.8627},
	{2381.5837, -339.3810, 5.6397},
	{2327.3252, -278.9656, 5.0695},
	{2180.4441, -283.5855, 5.0696},
	{2285.7036, -164.9460, 5.0660},
	{2314.4258, -74.2809, 5.3389},
	{0.0, 0.0, 0.0}
};

new minutes[MAX_PLAYERS];
new seconds[MAX_PLAYERS];
new playercheck[MAX_PLAYERS];

new timesfinished = 0; 
new respawn[MAX_PLAYERS]; 
new raceon = 0;

new setracestart = 0;

new playerinrace[MAX_PLAYERS]; 

new rcount = 0; 

new str[128],
	PlayerName[128];
	
new gRoundTimer,
	gRoundTime = 600000; // 10 minutes
	
new Text:BarTD[MAX_PLAYERS];
new UpdateTimer[MAX_PLAYERS];
new SecondTimer[MAX_PLAYERS];
	
main()
{
	print("*********************");
	print("* GTA:U MultiPlayer *");
	print("* Vice City Racing  *");
	print("*   by Andre9977    *");
}

public OnGameModeInit()
{
    SetGameModeText("GTA:U Race");

    ShowPlayerMarkers(1);
    ShowNameTags(1);

    AddPlayerClass(36,2105.7695,-361.3560,10.6444,133.2551,-1,-1,-1,-1,-1,-1);
    AddPlayerClass(37,2105.7695,-361.3560,10.6444,133.2551,-1,-1,-1,-1,-1,-1);

 	AddStaticVehicle(451,2313.2686,-24.2170,5.0699,356.3333,125,125); // Turismo1
	AddStaticVehicle(451,2316.4541,-24.4644,5.0705,356.0931,36,36); // Turismo1
	AddStaticVehicle(451,2319.3352,-24.4961,5.0694,355.8402,16,16); // Turismo1
	AddStaticVehicle(451,2322.2273,-24.7408,5.0704,355.3625,18,18); // Turismo1
	AddStaticVehicle(451,2324.9973,-25.0445,5.0699,355.5466,46,46); // Turismo1
	AddStaticVehicle(451,2327.7708,-25.0044,5.0704,355.1464,61,61); // Turismo1
	AddStaticVehicle(451,2312.8965,-30.3354,5.0696,355.7928,75,75); // Turismo2
	AddStaticVehicle(451,2315.9958,-30.6289,5.0692,355.3490,36,36); // Turismo2
	AddStaticVehicle(451,2318.8879,-31.0134,5.0695,355.9481,16,16); // Turismo2
	AddStaticVehicle(451,2321.7202,-31.2033,5.0697,355.4883,18,18); // Turismo2
	AddStaticVehicle(451,2324.5146,-31.4734,5.0695,355.6671,46,46); // Turismo2
	AddStaticVehicle(451,2327.2412,-31.4586,5.0684,355.2776,61,61); // Turismo2
	AddStaticVehicle(451,2312.4910,-36.2861,5.0690,356.0122,75,75); // Turismo3
	AddStaticVehicle(451,2315.5403,-36.3566,5.0692,355.3242,36,36); // Turismo3
	AddStaticVehicle(451,2318.5354,-36.4721,5.0704,356.1678,16,16); // Turismo3
	AddStaticVehicle(451,2321.3601,-36.6795,5.0700,357.8666,123,123); // Turismo3
	AddStaticVehicle(451,2324.0615,-36.7213,5.0704,358.0704,46,46); // Turismo3
	AddStaticVehicle(451,2327.0474,-36.8998,5.0697,357.7588,125,125); // Turismo3
	AddStaticVehicle(451,2312.0923,-42.0655,5.0697,356.0251,75,75); // Turismo4
	AddStaticVehicle(451,2315.0649,-42.2013,5.0689,355.3326,36,36); // Turismo4
	AddStaticVehicle(451,2318.1416,-42.3969,5.0697,356.1809,16,16); // Turismo4
	AddStaticVehicle(451,2321.1458,-42.5229,5.0699,357.8688,123,123); // Turismo4
	AddStaticVehicle(451,2323.7795,-42.5325,5.0691,358.0945,46,46); // Turismo4
	AddStaticVehicle(451,2326.8198,-42.7976,5.0704,357.7585,125,125); // Turismo4


    gRoundTimer = SetTimer("DefenceWin", gRoundTime, false);
    
    SetTimer("BeginRace", 1000, 1);
	return 1;
}

public TimeIsOver()
{
    GameTextForAll("~r~Time's up!", 5000, 5);
    SetTimer("ChangeMode", 3000, false);
    
}

public LastRacer()
{
	KillTimer(gRoundTimer);
	GameTextForAll("~r~Race is over!", 5000, 5);
	SetTimer("ChangeMode", 3000, false);
}

public ChangeMode()
{
    SendRconCommand("changemode /GTAU/RACE.amx");
}

public OnPlayerConnect(playerid)
{
	GetPlayerName(playerid, PlayerName, sizeof(PlayerName));
	format(str, sizeof(str), "SERVER: %s(id:%i) has joined the server.", PlayerName, playerid);
	SendClientMessageToAll(COLOR_GREY, str);
	
	SendClientMessage(playerid, COLOR_GREEN, "WELCOME! This is the GTA:United beta test on SA-MP!");
	SendClientMessage(playerid, COLOR_GREEN, "BETA GM: GTA: United Race (by Andre9977)");
    GameTextForPlayer(playerid,"~w~GTA United SA-MP: ~r~GTA:U Race",5000,5);
    
    SetVehicleToRespawn(playerid + 1);
    
    BarTD[playerid] = TextDrawCreate(163.000000,361.000000,"Please wait for the race to begin.");
	TextDrawAlignment(BarTD[playerid],0);
	TextDrawBackgroundColor(BarTD[playerid],0x00000099);
	TextDrawFont(BarTD[playerid],1);
	TextDrawLetterSize(BarTD[playerid],0.399999,1.300000);
	TextDrawColor(BarTD[playerid],0xffffffff);
	TextDrawSetOutline(BarTD[playerid],1);
	TextDrawSetProportional(BarTD[playerid],1);
	
    return 1;
}

public OnPlayerDisconnect(playerid, reason)
{
	KillTimer(UpdateTimer[playerid]);
	KillTimer(SecondTimer[playerid]);
	
	minutes[playerid] = 0;
	seconds[playerid] = 0;
	playercheck[playerid] = 0;
	
	TextDrawHideForPlayer(playerid, BarTD[playerid]);
	
    GetPlayerName(playerid, PlayerName, sizeof(PlayerName));
	switch(reason)
	{
	    case 0: format(str, sizeof(str), "crashed");
	    case 1: format(str, sizeof(str), "left");
	    case 2: format(str, sizeof(str), "got kicked / banned");
	}
    format(str, sizeof(str), "SERVER: %s(id:%i) has %s.", PlayerName, playerid, str);
	SendClientMessage(playerid, COLOR_GREY, str);
	return 1;
}

public OnPlayerCommandText(playerid, cmdtext[])
{
    return 0;
}

public OnPlayerSpawn(playerid)
{
    TextDrawShowForPlayer(playerid, BarTD[playerid]);
    
    PlayerPlaySound(playerid, 1186, 0, 0, 0);
	PlayerPlaySound(playerid, 1150, 0, 0, 0);

	SetPlayerColor(playerid, COLOR_GREEN);
	SetPlayerInterior(playerid, 0);
	
    GivePlayerMoney(playerid, 5000);
    
    if(respawn[playerid] == 0)
	{
		playerinrace[playerid] = 1;
		playercheck[playerid] = 0;

		PutPlayerInVehicle(playerid, playerid + 1, 0);

		SetCameraBehindPlayer(playerid);

		if(raceon == 0)
		{

			TogglePlayerControllable(playerid,0);
			GameTextForPlayer(playerid,"~w~Starting in:~g~ 5 secs", 4000, 5);
			SetTimer("BeginRace2", 5000, false);

		}
		else
		{

			GameTextForPlayer(playerid,"~r~GO, GO, GO!", 2000, 5);
			TogglePlayerControllable(playerid, 1);
			SetPlayerCheckpoint(playerid, checkpoints[0][0], checkpoints[0][1], checkpoints[0][2], 8);

		}
	}
    return 1;
}

public OnPlayerDeath(playerid, killerid, reason)
{
    TextDrawShowForPlayer(playerid, BarTD[playerid]);
    
    SetVehicleToRespawn(playerid + 1);
}

public OnPlayerEnterCheckpoint(playerid)
{
	UpdateTD(playerid);
	playercheck[playerid] = playercheck[playerid] + 1;

	if(playercheck[playerid] >= 1 && playercheck[playerid] <= MAXCP - 2)
	{
		DisablePlayerCheckpoint(playerid);
		SetPlayerCheckpoint(playerid, checkpoints[playercheck[playerid]][0], checkpoints[playercheck[playerid]][1], checkpoints[playercheck[playerid]][2],7.0);
		format(str, sizeof(str), "%d - %d", playercheck[playerid], MAXCP - 1);
		GameTextForPlayer(playerid, str, 2000, 6);
	}

	if(playercheck[playerid] == MAXCP - 1)
	{

		KillTimer(UpdateTimer[playerid]);
		KillTimer(SecondTimer[playerid]);
				
		timesfinished ++;

		if(timesfinished == 15 || timesfinished > 15)
		{
			LastRacer();
		}

		DisablePlayerCheckpoint(playerid);

		GetPlayerName(playerid, PlayerName, sizeof(PlayerName));

		new pos[10];
		if(timesfinished == 1) pos = "1st";
		if(timesfinished == 2) pos = "2nd";
		if(timesfinished == 3) pos = "3rd";
		if(timesfinished == 4) pos = "4th";
		if(timesfinished == 5) pos = "5th";
		if(timesfinished == 6) pos = "6th";
		if(timesfinished == 7) pos = "7th";
		if(timesfinished == 8) pos = "8th";
		if(timesfinished == 9) pos = "9th";
		if(timesfinished == 10) pos = "10th";
		if(timesfinished == 11) pos = "11th";
		if(timesfinished == 12) pos = "12th";
		if(timesfinished == 13) pos = "13th";
		if(timesfinished == 14) pos = "14th";
		if(timesfinished == 15) pos = "15th";

        format(str, sizeof(str), "~p~Finished in ~g~%d minutes ~p~and ~g~%d ~p~seconds as ~y~%s", minutes[playerid], seconds[playerid], pos);
		TextDrawSetString(BarTD[playerid], str);
		
		format(str,sizeof(str),"~r~%s(%i) ~g~finished %s!~n~", PlayerName, playerid, pos);
		GameTextForAll(str, 5000, 3);
		format(str, sizeof(str),"** %s (id:%i) finished %s (time: %d minutes, %d seconds)", PlayerName, playerid, pos, minutes[playerid], seconds[playerid]);
		SendClientMessageToAll(0x00FF00FF, str);
		SendClientMessage(playerid, COLOR_WHITE, "Please wait until the race finishes.");

		respawn[playerid] = 1;
	}
	return 1;
}

public OnPlayerRequestClass(playerid, classid)
{
    GameTextForPlayer(playerid, "~g~Racers", 2000, 5);
    SetupPlayerForClassSelection(playerid);
    return 1;
}

public SetupPlayerForClassSelection(playerid)
{
    SetPlayerInterior(playerid, 0);
    SetPlayerPos(playerid, 2079.4976, -365.7190, 9.0355);
    SetPlayerFacingAngle(playerid, 283.0);
    SetPlayerCameraPos(playerid, 2090.0, -364.3, 11.5);
    SetPlayerCameraLookAt(playerid, 2079.4976, -365.7190, 9.0355);
}

public BeginRace2()
{
	setracestart = 1;
	BeginRace();
	return 1;
}

public BeginRace()
{
	if(setracestart == 1)
	{
		for(new i = 0; i < GetMaxPlayers(); i++)
  		{
	        if(playerinrace[i] == 1 && rcount == 0)
			{
		        GameTextForPlayer(i,"~w~Get ready!",1000,4);
		        PlayerPlaySound(i, 1052, 0, 0, 0);
		        print("RACE: 4");
		        
		        format(str, sizeof(str), "~p~Get ready to race!");
				TextDrawSetString(BarTD[i], str);
			}
	        if(playerinrace[i] == 1 && rcount == 1)
			{
		        GameTextForPlayer(i,"~g~3",1000,3);
		        PlayerPlaySound(i, 1053, 0, 0, 0);
		        print("RACE: 3");
		        
		        format(str, sizeof(str), "~p~3");
				TextDrawSetString(BarTD[i], str);
			}
	        if(playerinrace[i] == 1 && rcount == 2)
			{
		        GameTextForPlayer(i,"~g~2",1000,3);
		        PlayerPlaySound(i, 1053, 0, 0, 0);
		        print("RACE: 2");
		        
		        format(str, sizeof(str), "~p~2");
				TextDrawSetString(BarTD[i], str);
			}
	        if(playerinrace[i] == 1 && rcount == 3)
			{
		        GameTextForPlayer(i,"~g~1",1000,3);
		        PlayerPlaySound(i, 1053, 0, 0, 0);
				print("RACE: 1");
				
				format(str, sizeof(str), "~p~1");
				TextDrawSetString(BarTD[i], str);
			}
	        if(playerinrace[i] == 1 && rcount == 4)
			{
		        GameTextForPlayer(i,"~r~Let's roll!", 2000, 3);
		        PlayerPlaySound(i, 1085, 0, 0, 0);
		        TogglePlayerControllable(i, 1);
		        SetPlayerCheckpoint(i, checkpoints[0][0], checkpoints[0][1], checkpoints[0][2], 8);

                format(str, sizeof(str), "~r~Go, Go, Go!");
				TextDrawSetString(BarTD[i], str);
				
				SecondTimer[i] = SetTimerEx("CountSeconds", 910, true, "i", i);
				UpdateTimer[i] = SetTimerEx("UpdateTD", 910, true, "i", i);
				print("RACE: started");
		        raceon = 1;
			}
		}

		rcount = rcount + 1;
	}

	return 1;
}

forward UpdateTD(playerid);
public UpdateTD(playerid)
{
	for(new i = 0; i < GetMaxPlayers(); i++)
	{
		format(str, sizeof(str), "~w~Time: ~r~%d ~y~minutes~w~, ~r~%d ~w~~y~seconds ~w~Checkpoints: ~y~%d~w~/~g~%d", minutes[i], seconds[i], playercheck[i], MAXCP-1);
		TextDrawSetString(BarTD[playerid], str);
	}
}

forward CountSeconds(playerid);
public CountSeconds(playerid)
{
	seconds[playerid] = seconds[playerid] + 1;
	if(seconds[playerid] == 60)
	{
	    minutes[playerid] = minutes[playerid] + 1;
	    seconds[playerid] = 0;
	}
	return true;
}
