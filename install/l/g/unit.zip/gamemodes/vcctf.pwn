#include <a_samp>           /* by Kapil */


new Vehi1,Vehi2;
new Text:Draw;
new Zone;
enum PositionsEnum
{
	Float:x,
	Float:y,
	Float:z,
};

new Positions[][PositionsEnum] =
{
	{ -2490.3738,2288.9382,68.1821 },// red flag
	{ -2256.5720,527.8834,10.8102 },// blue flag

	{ -2488.3198,2295.7222,68.1890 },//
	{ -2493.5652,2299.1936,68.1941 },//
	{ -2495.5256,2295.8479,68.1932 },//
	{ -2499.8767,2292.8523,68.1959 },//
	{ -2497.2095,2289.8936,68.1898 },//

	{ -2253.2070,515.3770,10.8102 },//
	{ -2262.6489,520.3207,10.8102 },//
	{ -2250.2952,533.7520,10.8051 },//
	{ -2248.2593,528.5820,10.8102 },//
	{ -2251.1904,526.6586,10.8102 }//
};

new Team[MAX_PLAYERS];// 1 Red , 2 Blue

const Red_Flag = 2993;
const Blue_Flag = 2993;

#define Red_Color 0xFF6347AA
#define Blue_Color 0x33CCFFAA

new RedFlagWith = -1;
new BlueFlagWith = -1;

new RedPickup;
new BluePickup;
new Tips[][256] =
{
	{"TIP: You can use 'T <message>' to send a message to your team." },
	{"TIP: You gain weapons and ammos for each player you kill." },
	{"TIP: You can Hold 'ALT' to spectate your base anytime."},
	{"TIP: The team score is the sum of scores of all the players of that team."},
	{"TIP: The yellow markers represent the base's."}

};

IsRedSkin(skin)
{
	switch(skin)
	{
	    case 19: return 1;
	    case 49: return 1;
	    case 80: return 1;
	    case 97: return 1;
	    case 170: return 1;
	    case 193: return 1;
	    case 213: return 1;
	}
	return 0;
}

name(playerid)
{
	new str[23];
	GetPlayerName(playerid,str,23);
	return str;
}

Message(team,text[])
{
	if(team == 0)
	{
	    GameTextForAll(text,5000,5);
	}
	if(team == 1)
	{
	    for(new i = 0; i < MAX_PLAYERS;i++)
	    {
	        if((IsPlayerConnected(i)) && (Team[i] == 1))
	    		GameTextForPlayer(i,text,5000,5);
	    }
	}
	if(team == 2)
	{
	    for(new i = 0; i < MAX_PLAYERS;i++)
	    {
	        if((IsPlayerConnected(i)) && (Team[i] == 2))
	    		GameTextForPlayer(i,text,5000,5);
	    }
	}
}

RedTeamScore()
{
	new score;
	for(new i = 0;i < MAX_PLAYERS;i++)
	{
	    if(IsPlayerConnected(i) && Team[i] == 1)
	    {
			score+=GetPlayerScore(i);
	    }
	}
	return score;
}

BlueTeamScore()
{
	new score;
	for(new i = 0;i < MAX_PLAYERS;i++)
	{
	    if(IsPlayerConnected(i) && Team[i] == 2)
	    {
			score+=GetPlayerScore(i);
	    }
	}
	return score;
}

forward ScoreManager();
public ScoreManager()
{
	new string[50];
	format(string,50,"~r~RED:  %d~n~~b~BLUE: %d",RedTeamScore(),BlueTeamScore());
	TextDrawSetString(Draw,string);
}

forward TipManager();
public TipManager()
{
	SendClientMessageToAll(0x9ACD32AA,Tips[random(sizeof(Tips))]);
}

main()
{
	print("---------------------------");
	print(" Capture The Flag by KAPIL ");
	print("---------------------------");
}

public OnGameModeInit()
{
	SetGameModeText("Capture The Flag");
	UsePlayerPedAnims();

	AddPlayerClass(19, -463.0549,1493.0459,8.5080, 269.1425, 29, 250, 31, 100, 38, 50);
	AddPlayerClass(49, -463.0549,1493.0459,8.5080, 269.1425, 29, 250, 31, 100, 38, 50);
	AddPlayerClass(80, -463.0549,1493.0459,8.5080, 269.1425, 29, 250, 31, 100, 38, 50);
	AddPlayerClass(97, -463.0549,1493.0459,8.5080, 269.1425, 29, 250, 31, 100, 38, 50);
	AddPlayerClass(170, -463.0549,1493.0459,8.5080, 269.1425, 29, 250, 31, 100, 38, 50);
	AddPlayerClass(193, -463.0549,1493.0459,8.5080, 269.1425, 29, 250, 31, 100, 38, 50);
	AddPlayerClass(219, -463.0549,1493.0459,8.5080, 269.1425, 29, 250, 31, 100, 38, 50);

	AddPlayerClass(275, -463.0549,1493.0459,8.5080, 269.1425, 29, 250, 31, 100, 38, 50);
	AddPlayerClass(176, -463.0549,1493.0459,8.5080, 269.1425, 29, 250, 31, 100, 38, 50);
	AddPlayerClass(177, -463.0549,1493.0459,8.5080, 269.1425, 29, 250, 31, 100, 38, 50);
	AddPlayerClass(156, -463.0549,1493.0459,8.5080, 269.1425, 29, 250, 31, 100, 38, 50);
	AddPlayerClass(143, -463.0549,1493.0459,8.5080, 269.1425, 29, 250, 31, 100, 38, 50);
	AddPlayerClass(69, -463.0549,1493.0459,8.5080, 269.1425, 29, 250, 31, 100, 38, 50);
	AddPlayerClass(81, -463.0549,1493.0459,8.5080, 269.1425, 29, 250, 31, 100, 38, 50);

	AddStaticVehicle(468,-2232.0320,546.5345,10.5399,71.8453,-1,-1); //
	AddStaticVehicle(468,-2230.9995,549.6280,10.5365,70.4758,-1,-1); //
	AddStaticVehicle(468,-2249.3770,507.5052,10.5340,76.3238,-1,-1); //
	AddStaticVehicle(468,-2250.4839,503.6208,10.5282,75.6604,-1,-1); //
	AddStaticVehicle(468,-2482.7739,2310.9551,67.9338,208.4042,-1,-1); //
	AddStaticVehicle(468,-2479.2402,2313.1963,67.9365,206.7812,-1,-1); //
	AddStaticVehicle(468,-2510.9644,2296.5071,67.9385,213.4500,-1,-1); //
	AddStaticVehicle(468,-2514.8132,2293.9885,67.9343,211.3599,-1,-1); //
	AddStaticVehicle(468,-2318.2429,2334.5286,67.6054,268.7079,-1,-1); //
	AddStaticVehicle(468,-2202.4441,2160.7988,42.7097,264.3953,-1,-1); //
	AddStaticVehicle(468,-2106.1960,2166.7776,60.2703,261.2253,-1,-1); //
	AddStaticVehicle(468,-1804.2595,2158.0969,85.9533,259.3636,-1,-1); //
	AddStaticVehicle(468,-1558.9003,2084.1162,3.2561,359.9433,-1,-1); //
	AddStaticVehicle(468,-1618.4667,1926.6558,3.5503,181.7472,-1,-1); //
	AddStaticVehicle(468,-1793.2422,1851.0287,3.5481,174.6500,-1,-1); //
	AddStaticVehicle(468,-1797.4193,1672.9071,3.5387,164.3050,-1,-1); //
	AddStaticVehicle(468,-2057.6899,1691.9116,3.5451,29.5424,-1,-1); //
	AddStaticVehicle(468,-2443.2024,2068.3518,3.4726,79.9884,-1,-1); //
	AddStaticVehicle(468,-2261.2300,1718.6451,32.5926,198.4864,-1,-1); //
	AddStaticVehicle(468,-2293.4998,1664.4724,33.5582,87.4217,-1,-1); //
	AddStaticVehicle(468,-2243.5039,1502.1484,33.5477,270.6157,-1,-1); //
	AddStaticVehicle(468,-2022.6978,1161.0122,0.8609,253.1230,-1,-1); //
	AddStaticVehicle(468,-2361.7627,2334.7021,68.1253,272.1160,-1,-1); //
	AddStaticVehicle(468,-2227.6707,2201.3833,42.3050,180.2034,-1,-1); //
	AddStaticVehicle(468,-2238.7700,2021.9281,26.7488,247.3622,-1,-1); //
	AddStaticVehicle(468,-2029.3190,1696.9412,3.5441,221.9417,-1,-1); //
	AddStaticVehicle(468,-1792.4442,1610.1084,3.5452,355.8413,-1,-1); //
	AddStaticVehicle(468,-2621.3242,2058.7356,68.4538,182.5070,-1,255); //
	AddStaticVehicle(468,-2608.5737,1887.5863,68.4183,178.3832,-1,255); //
	AddStaticVehicle(468,-2609.7346,1568.8739,51.1530,262.3286,-1,255); //
	AddStaticVehicle(468,-2362.3596,1920.3193,48.4938,289.5081,-1,255); //
	AddStaticVehicle(468,-1896.3867,2014.6300,64.3529,268.2511,-1,255); //
	AddStaticVehicle(468,-1657.0375,2285.8455,88.1946,160.2101,-1,255); //
	AddStaticVehicle(468,-2615.9141,2141.0129,67.9258,171.7768,-1,255); //
	AddStaticVehicle(468,-2609.3857,1879.7092,68.5364,176.7763,-1,255); //
	AddStaticVehicle(468,-2607.4966,1799.8604,63.2340,306.3309,-1,255); //
	AddStaticVehicle(468,-2458.4590,1714.2388,46.7419,208.6584,-1,255); //
	AddStaticVehicle(468,-2477.1370,1570.3273,43.5007,103.0299,-1,255); //
	AddStaticVehicle(468,-2892.6731,844.5244,10.4864,272.1186,-1,255); //

	Vehi1 = CreateVehicle(473,Positions[0][x],Positions[0][y],-99,0,-1,-1,0);
	Vehi2 = CreateVehicle(473,Positions[1][x],Positions[1][y],-99,0,-1,-1,0);


	RedPickup = CreatePickup(Red_Flag,15,Positions[0][x],Positions[0][y],Positions[0][z]);
	BluePickup = CreatePickup(Blue_Flag,15,Positions[1][x],Positions[1][y],Positions[1][z]);

    Draw = TextDrawCreate(525,350,"~r~RED:  0~n~~b~BLUE: 0");
	TextDrawFont(Draw,2);
	TextDrawUseBox(Draw,1);
	TextDrawTextSize(Draw,625,1);
	TextDrawBoxColor(Draw,0x000000A );
	TextDrawSetShadow(Draw,0);
	TextDrawSetOutline(Draw,1);

	Zone = GangZoneCreate(-9999,-9999,9999,9999);

	SetTimer("TipManager",100 * 1000,1);
	SetTimer("ScoreManager",5 * 1000,1);

	return 1;
}

public OnPlayerDisconnect(playerid,reason)
{
	if(RedFlagWith == playerid)
	{
		RedPickup = CreatePickup(Red_Flag,15,Positions[0][x],Positions[0][y],Positions[0][z]);
		RedFlagWith = -1;
		Message(0,"~r~RED~w~ flag restored.");
	}
	if(BlueFlagWith == playerid)
	{
		BluePickup = CreatePickup(Blue_Flag,15,Positions[1][x],Positions[1][y],Positions[1][z]);
		BlueFlagWith = -1;
		Message(0,"~b~BLUE~w~ flag restored.");
	}

	new string[128];
	format(string,128,"%s has left the game.",name(playerid));
	SendClientMessageToAll(Team[playerid]==1?Red_Color:Blue_Color,string);
	Team[playerid] = 0;
}

public OnPlayerRequestClass(playerid, classid)
{
	SetPlayerPos(playerid,-702.3599,1480.8318,12.0304);
	SetPlayerFacingAngle(playerid,0);
	SetPlayerCameraPos(playerid,-703.1814,1486.7400,15);
	SetPlayerCameraLookAt(playerid,-702.3599,1480.8318,12.0304);
	return 1;
}

public OnPlayerRequestSpawn(playerid)
						return 1;

public OnPlayerSpawn(playerid)
{
	if(Team[playerid] == 0)
	{
		new string[128];
		format(string,128,"%s has joined the game.",name(playerid));
		SendClientMessageToAll(Team[playerid]==1?Red_Color:Blue_Color,string);
	}

	new skin = GetPlayerSkin(playerid);
	if(IsRedSkin(skin))
	{
		Team[playerid] = 1;
		SetPlayerTeam(playerid,1);
		SetPlayerPos(playerid,Positions[2+random(4)][x],Positions[2+random(4)][y],Positions[2+random(4)][z]);
	}
	else
	{
		Team[playerid] = 2;
		SetPlayerTeam(playerid,2);
		SetPlayerPos(playerid,Positions[2+5+random(4)][x],Positions[2+5+random(4)][y],Positions[2+5+random(4)][z]);
	}
	SetPlayerColor(playerid,Team[playerid]==1?Red_Color:Blue_Color);

	SetPlayerMapIcon(playerid,0,Positions[0][x],Positions[0][y],Positions[0][z],20,Red_Color);
	SetPlayerMapIcon(playerid,1,Positions[1][x],Positions[1][y],Positions[1][z],30,Blue_Color);

	TextDrawShowForPlayer(playerid,Draw);

	SetVehicleParamsForPlayer(Vehi1,playerid,1,1);
	SetVehicleParamsForPlayer(Vehi2,playerid,1,1);

	return 1;
}

public OnPlayerCommandText(playerid, cmdtext[])
{
	if(IsPlayerAdmin(playerid))
	{
		if (strcmp("/h", cmdtext, true) == 0)
		{
			new Float:X,Float:Y,Float:Z;
			GetPlayerPos(playerid,X,Y,Z);
			PutPlayerInVehicle(playerid,CreateVehicle(548,X,Y,Z,0,-1,-1,-1),0);
			return 1;
		}
		if (strcmp("/c", cmdtext, true) == 0)
		{
			new Float:X,Float:Y,Float:Z;
			GetPlayerPos(playerid,X,Y,Z);
			PutPlayerInVehicle(playerid,CreateVehicle(411,X,Y,Z,0,-1,-1,-1),0);
			return 1;
		}
		if(strcmp("/o",cmdtext,true,2)==0)
		{
		    new Float:X,Float:Y,Float:Z;
		    GetPlayerPos(playerid,X,Y,Z);
		    CreateObject(strval(cmdtext[3]),X+5,Y,Z,0,0,0);
		}
		if(strcmp("/red",cmdtext,true)==0)
		{
		    SetPlayerPos(playerid,Positions[0][x],Positions[0][y]+5,Positions[0][z]);
		}
		if(strcmp("/blue",cmdtext,true)==0)
		{
			SetPlayerPos(playerid,Positions[1][x],Positions[1][y]+5,Positions[1][z]);
		}
	}
	return 0;
}

public OnPlayerText(playerid,text[])
{
	if(strcmp(text,"t ",true,2)==0)
	{
		new string[256];
		format(string,256,"%s: %s",name(playerid),text);
	    for(new i = 0;i < MAX_PLAYERS;i++)
	    {
	        if((IsPlayerConnected(i)) && (Team[playerid] == Team[i]))
	        {
				SendClientMessage(playerid,Team[playerid]==1?Red_Color:Blue_Color,string);
	        }
	    }
	    return 0;
	}
	return 1;
}


public OnPlayerPickUpPickup(playerid,pickupid)
{
	if(pickupid == RedPickup)
	{
	    if(Team[playerid] == 2)
	    {
		    RedFlagWith = playerid;
		    new string[256];
		    format(string,256,"~b~%s~w~ has the ~r~RED~w~ flag.",name(playerid));
		    Message(0,string);
		    format(string,256,"%s - FLAG",name(playerid));
		    SetPlayerName(playerid,string);
			GangZoneFlashForAll(Zone,Red_Color);
		}
		else
		{
		    if(BlueFlagWith == playerid)
			{
			    new string[256];
			    format(string,256,"~r~%s~w~ has captured the ~b~BLUE~w~ flag.",name(playerid));
			    Message(0,string);
				SetPlayerScore(playerid,GetPlayerScore(playerid)+1);
				RedPickup = CreatePickup(Red_Flag,15,Positions[0][x],Positions[0][y],Positions[0][z]);
				BluePickup = CreatePickup(Blue_Flag,15,Positions[1][x],Positions[1][y],Positions[1][z]);
				BlueFlagWith = -1;
			}
			else
			{
				RedPickup = CreatePickup(Red_Flag,15,Positions[0][x],Positions[0][y],Positions[0][z]);
			}
		}
	}
	if(pickupid == BluePickup)
	{
	    if(Team[playerid] == 1)
		{
		    BlueFlagWith = playerid;
		    new string[256];
		    format(string,256,"~r~%s~w~ has the ~b~BLUE~w~ flag.",name(playerid));
		    Message(0,string);
		    format(string,256,"%s - FLAG",name(playerid));
		    SetPlayerName(playerid,string);
			GangZoneFlashForAll(Zone,Blue_Color);
		}
		else
		{
		    if(RedFlagWith == playerid)
		    {
			    new string[256];
			    format(string,256,"~b~%s~w~ has captured the ~r~RED~w~ flag.",name(playerid));
			    Message(0,string);
				SetPlayerScore(playerid,GetPlayerScore(playerid)+1);
				RedPickup = CreatePickup(Red_Flag,15,Positions[0][x],Positions[0][y],Positions[0][z]);
				BluePickup = CreatePickup(Blue_Flag,15,Positions[1][x],Positions[1][y],Positions[1][z]);
				RedFlagWith = -1;
		    }
		    else
		    {
				BluePickup = CreatePickup(Blue_Flag,15,Positions[1][x],Positions[1][y],Positions[1][z]);
			}
		}
	}
	return 1;
}

public OnPlayerDeath(playerid,killerid,reason)
{
	if(RedFlagWith == playerid)
	{
		RedPickup = CreatePickup(Red_Flag,15,Positions[0][x],Positions[0][y],Positions[0][z]);
		RedFlagWith = -1;
		if(!IsPlayerConnected(killerid))
		{
			Message(0,"~r~RED~w~ flag restored.");
			if(strfind(name(playerid),"-",false)!=-1)
			{
			    new Name[23];
				strmid(Name,name(playerid),strfind(name(playerid),"-",false)-1,strlen(name(playerid)));
			}
		}
		else
		{
		    new string[128];
		    format(string,128,"~r~%s~w has restored the ~r~RED~w~ flag.",name(killerid));
		    Message(0,string);
		}
	}
	if(BlueFlagWith == playerid)
	{
		BluePickup = CreatePickup(Blue_Flag,15,Positions[1][x],Positions[1][y],Positions[1][z]);
		BlueFlagWith = -1;
		if(!IsPlayerConnected(killerid))
		{
			Message(0,"~b~BLUE~w~ flag restored.");
		}
		else
		{
		    new string[128];
		    format(string,128,"~b~%s~w has restored the ~b~BLUE~w~ flag.",name(killerid));
		    Message(0,string);
		}
	}

	GivePlayerWeapon(killerid,31,100);
	GivePlayerWeapon(killerid,38,50);
 	GivePlayerWeapon(killerid,24,250);

	return 1;
}

public OnPlayerKeyStateChange(playerid,newkeys,oldkeys)
{

	if((newkeys == KEY_WALK && GetPlayerState(playerid)==PLAYER_STATE_ONFOOT) || (newkeys == 4 && IsPlayerInAnyVehicle(playerid)))
	{
	    if(Team[playerid]==1)
	    {
	        SetPlayerCameraPos(playerid,Positions[0][x]+8,Positions[0][y]+8,Positions[0][z]+8);
	        SetPlayerCameraLookAt(playerid,Positions[0][x],Positions[0][y],Positions[0][z]);
	    }
	    else
	    {
	    	SetPlayerCameraPos(playerid,Positions[1][x]+8,Positions[1][y]+8,Positions[1][z]+8);
	    	SetPlayerCameraLookAt(playerid,Positions[1][x],Positions[1][y],Positions[1][z]);
	    }
	}
	if((oldkeys == KEY_WALK && GetPlayerState(playerid)==PLAYER_STATE_ONFOOT) || (oldkeys == 4 && IsPlayerInAnyVehicle(playerid)))
	{
	    SetCameraBehindPlayer(playerid);
	}
	return 1;
}
                    						     /* by Kapil */
