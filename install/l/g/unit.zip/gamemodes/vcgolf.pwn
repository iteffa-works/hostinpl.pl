#include <a_samp>

#define COLOR_YELLOW 0xFFFF00AA
#define COLOR_WHITE 0xFFFFFFAA
#define INACTIVE_PLAYER_ID INVALID_PLAYER_ID

#define COLOR_GREY 			0xAFAFAFAA
#define COLOR_PURPLE 		0xC2A2DAAA
#define COLOR_YELLOW 		0xFFFF00AA
#define COLOR_WHITE 		0xFFFFFFAA
#define COLOR_DBLUE 		0x2641FEAA
#define COLOR_BLUE 			0x33AAFFFF
#define COLOR_GREEN 		0x33AA33AA
#define COLOR_ORANGE 		0xFF9900AA
#define COLOR_GREY 			0xAFAFAFAA
#define COLOR_GREEN 		0x33AA33AA
#define COLOR_RED 			0xAA3333AA
#define COLOR_LIGHTRED 		0xFF6347AA
#define COLOR_LIGHTBLUE 	0x33CCFFAA
#define COLOR_LIGHTGREEN 	0x9ACD32AA
#define COLOR_YELLOW 		0xFFFF00AA
#define COLOR_YELLOW2 		0xF5DEB3AA
#define COLOR_WHITE 		0xFFFFFFAA
#define COLOR_FADE1 		0xE6E6E6E6
#define COLOR_FADE2 		0xC8C8C8C8
#define COLOR_FADE3 		0xAAAAAAAA
#define COLOR_FADE4 		0x8C8C8C8C
#define COLOR_FADE5 		0x6E6E6E6E
#define COLOR_PURPLE 		0xC2A2DAAA
#define COLOR_DBLUE 		0x2641FEAA
#define COLOR_CYAN 			0x00FFFFAA
#define COLOR_SYSTEM 		0xEFEFF7AA

forward SetupPlayerForClassSelection(playerid);

new str[128],
	PlayerName[128];

main()
{
    print("\n----------------------------------");
    print("  Running VCGOLF\n");
    print("----------------------------------\n");
}

//------------------------------------------------------------------------------------------------------

public OnPlayerConnect(playerid)
{
	GetPlayerName(playerid, PlayerName, sizeof(PlayerName));
	format(str, sizeof(str), "SERVER: %s(id:%i) has joined the server.", PlayerName, playerid);
	SendClientMessageToAll(COLOR_GREY, str);

	SendClientMessage(playerid, COLOR_GREEN, "WELCOME! This is the GTA:United beta test on SA-MP!");
    GameTextForPlayer(playerid,"~w~SA-MP: ~r~Vice City Golfers",5000,5);
    return 1;
}

public OnPlayerDisconnect(playerid, reason)
{
    GetPlayerName(playerid, PlayerName, sizeof(PlayerName));
	switch(reason)
	{
	    case 0: format(str, sizeof(str), "crashed");
	    case 1: format(str, sizeof(str), "left");
	    case 2: format(str, sizeof(str), "got kicked / banned");
	}
    format(str, sizeof(str), "SERVER: %s(id:%i) has %s.", PlayerName, playerid, str);
	SendClientMessage(playerid, COLOR_GREY, str);
	return 1;
}

//------------------------------------------------------------------------------------------------------

public OnPlayerCommandText(playerid, cmdtext[])
{

    // PROCESS OTHER COMMANDS
    return 0;
}

//------------------------------------------------------------------------------------------------------

public OnPlayerSpawn(playerid)
{
    GivePlayerMoney(playerid, 5000);
    SetPlayerInterior(playerid,0);
    return 1;
}

//------------------------------------------------------------------------------------------------------

public OnPlayerRequestClass(playerid, classid)
{
    SetupPlayerForClassSelection(playerid);
    return 1;
}

//------------------------------------------------------------------------------------------------------

public SetupPlayerForClassSelection(playerid)
{
    SetPlayerInterior(playerid,0);
    SetPlayerPos(playerid,2079.4976,-365.7190,9.0355);
    SetPlayerFacingAngle(playerid, 283.0);
    SetPlayerCameraPos(playerid,2090.0,-364.3,11.5);
    SetPlayerCameraLookAt(playerid,2079.4976,-365.7190,9.0355);
}

//------------------------------------------------------------------------------------------------------

public OnGameModeInit()
{
    SetGameModeText("VC Golfers");

    ShowPlayerMarkers(1);
    ShowNameTags(1);

    // Player Class's
    AddPlayerClass(36,2105.7695,-361.3560,10.6444,133.2551,-1,-1,-1,-1,-1,-1);
    AddPlayerClass(37,2105.7695,-361.3560,10.6444,133.2551,-1,-1,-1,-1,-1,-1);      //AddPlayerClass(36,2105.7695,-361.3560,10.6444,133.2551,-1,-1,-1,-1,-1,-1);

	// Car Spawns
 	AddStaticVehicle(457,2092.6970,-384.9203,8.5675,302.5876,32,1); // cart 0
 	AddStaticVehicle(457,2094.6721,-387.5885,8.5302,307.5844,32,1); // cart 1
  	AddStaticVehicle(457,2096.4443,-390.2299,8.4678,309.0581,58,1); // cart 2
   	AddStaticVehicle(457,2097.9458,-392.5794,8.4098,304.3466,13,1); // cart 3
    AddStaticVehicle(457,2099.7400,-395.2281,8.3431,302.3403,32,1); // cart 4
    AddStaticVehicle(457,2101.3503,-397.8755,8.2912,306.1211,58,1); // cart 5
    AddStaticVehicle(457,2082.7864,-359.9477,8.4140,215.0355,63,1); // cart 6
    AddStaticVehicle(457,2084.9912,-357.9448,8.3997,224.6544,13,1); // cart 7
    AddStaticVehicle(457,2082.2002,-353.5650,8.4703,279.8132,63,1); // cart 8

	return 1;
}

