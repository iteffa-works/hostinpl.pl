//---------------------------------------------------------
//
// MONSTER! A freeroam script centered around the desert.
//   by Mike
//---------------------------------------------------------

#include <a_samp>

#define COLOR_RED 0xAA3333AA

forward GameModeExitFunc();
new gRoundTime = 0;

//---------------------------------------------------------

main()
{
	print("\n----------------------------------");
	print("  Monster freeroam by Mike (2006)\n");
	print("----------------------------------\n");
}

//---------------------------------------------------------

public OnGameModeInit()
{
	new Float:monsterX = 353.8362;
	new Float:bikeX = 346.4003;
	new Float:boatY = -1685.8817;
	new id;
	new count;

	AddPlayerClass(36,280.4139,-1693.2511,9.3215,6.7277,0,0,0,0,0,0); //
	AddStaticVehicle(557,351.2509,-1673.7211,9.6998,172.3421,1,1); //

	SetGameModeText("Monster freeroam");
	
	// Players
	for (id = 254; id <= 288; id++)
	{
		if (id == 265) id = 274; // Skip over the bad ones
		AddPlayerClass(id, 280.4139,-1693.2511,9.3215,6.7277,0,0,0,0,0,0);
	}
	
	// Monsters
	for(count = 0; count <= 20; count++)
	{
		AddStaticVehicle(557, monsterX, -1673.6199, 8.9481, 178.3666, 1, 1);
		monsterX -= 9.0;
	}

	// Mountain bikes/BMXes
	for(count = 0; count <= 20; count++)
	{
		AddStaticVehicle(510,bikeX,-1693.1257,9.3252,4.5001,-1,-1);
		bikeX -= 2.5;
	}
	
	for(count = 0; count <= 6; count++)
	{
		AddStaticVehicle(473,143.3049,boatY,-0.4818,167.1644,-1,-1);
		boatY -= 15.0;
	}
	

	if (gRoundTime > 0)
	{
	    SetTimer("GameModeExitFunc", gRoundTime, 0);
	}
	return 1;
}

//---------------------------------------------------------

public OnPlayerConnect(playerid)
{
	GameTextForPlayer(playerid,"~w~Monster freeroam!",1000,5);
	return 1;
}

//---------------------------------------------------------

SetupPlayerForClassSelection(playerid)
{
	SetPlayerPos(playerid,398.4077,2540.5049,19.6311);
	SetPlayerCameraPos(playerid,398.4077,2530.5049,19.6311);
	SetPlayerCameraLookAt(playerid,398.4077,2540.5049,19.6311);
	SetPlayerFacingAngle(playerid, 180.0);
}

//---------------------------------------------------------

public OnPlayerRequestClass(playerid, classid)
{
	SetupPlayerForClassSelection(playerid);
	return 1;
}

//---------------------------------------------------------

public OnPlayerDeath(playerid, killerid, reason)
{
	new name[256];
	new string[256];
	GetPlayerName(playerid, name, sizeof(name));
	format(string, sizeof(string), "*** %s died.", name);
	SendClientMessageToAll(COLOR_RED, string);
 	return 1;
}

//---------------------------------------------------------

public GameModeExitFunc()
{
	GameModeExit();
}
