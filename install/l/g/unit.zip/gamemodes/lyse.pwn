// Local Yokel
// Coded By Jax of the SA-MP Team. Based off Rivershell coded by Kyeman.
// ported to gta united by dugi


#include <a_samp>
#include <core>
#include <float>

#define COLOR_GREY 0xAFAFAFAA
#define COLOR_GREEN 0x33AA33AA
#define COLOR_RED 0xAA3333AA
#define COLOR_YELLOW 0xFFFF00AA
#define OBJECTIVE_COLOR 0xE2C063FF

forward SetPlayerToTeamColor(playerid);
forward SetPlayerTeamFromClass(playerid,classid);
forward SetPlayerRandomSpawn(playerid);
forward ExitTheGameMode();
forward SetupPlayerForClassSelection(playerid);
forward SendAllFormattedText(playerid, const str[], define);
forward SendPlayerFormattedText(playerid, const str[], define);


static gTeam[MAX_PLAYERS]; // Tracks the team assignment for each player

#define OBJECTIVE_VEHICLE_BLUE 2
#define OBJECTIVE_VEHICLE_GREEN 1
#define TEAM_BLUE 1  //tg
#define TEAM_GREEN 2  //tb
#define TEAM_BLUE_COLOR 0x0000FFAA
#define TEAM_GREEN_COLOR 0x33AA33AA

#define GAME_ROUNDLIMIT 3

new gObjectiveBluePlayer=(-1);
new gObjectiveGreenPlayer=(-1);
new gObjectiveReached=0;
new gGreenScore=0;
new gBlueScore=0;

new Float:gTeam1RandomPlayerSpawns[4][3] = {
{-353.7755,917.2556,14.9241},
{-344.9242,915.4851,14.9241},
{-353.7021,924.8918,14.9241},
{-342.2384,925.0466,14.9241}
};

new Float:gTeam2RandomPlayerSpawns[4][3] = {
{66.3979,992.8365,11.7848},
{50.7428,995.1035,11.7840},
{61.6316,971.0161,11.7840},
{42.0251,1008.5319,11.8656}
};

new Float:gTeam1CapCarSpawns[3][4] = {
{-349.2464,938.9315,15.5271},
{-331.7032,932.8788,15.5243},
{-324.0351,926.6680,15.5278}
};

new Float:gTeam2CapCarSpawns[3][4] = {
{45.7457,965.8329,12.3969},
{44.8299,1000.4438,12.4163},
{64.1451,979.6497,12.3928}
};

main()
{
	print("\n----------------------------------");
	print("  Running LocalYokel: Liberty City\n");
	print("----------------------------------\n");
}

public OnPlayerStateChange(playerid, newstate, oldstate)
{
	new vehicleid;

	if(newstate == PLAYER_STATE_DRIVER)
	{
		vehicleid = GetPlayerVehicleID(playerid);

		if(gTeam[playerid] == TEAM_GREEN && vehicleid == OBJECTIVE_VEHICLE_BLUE)
		{ // It's the objective vehicle
		    SetPlayerColor(playerid,OBJECTIVE_COLOR);
		    GameTextForPlayer(playerid,"~w~Take the ~y~truck ~w~back to our base!",5000,5);
		    gObjectiveBluePlayer = playerid;
		    SetPlayerCheckpoint(playerid,-339.2301,946.8410,14.9242,7.0);
		}

		if(gTeam[playerid] == TEAM_BLUE && vehicleid == OBJECTIVE_VEHICLE_GREEN)
		{ // It's the objective vehicle
		    SetPlayerColor(playerid,OBJECTIVE_COLOR);
		    GameTextForPlayer(playerid,"~w~Take the ~y~truck ~w~back to our base!",5000,5);
		    gObjectiveGreenPlayer = playerid;
		    SetPlayerCheckpoint(playerid,45.7434,980.8965,11.7877,7.0);
		}
	}
	else if(newstate == PLAYER_STATE_ONFOOT)
	{
		if(playerid == gObjectiveBluePlayer) {
		    gObjectiveBluePlayer = (-1);
		    SetPlayerToTeamColor(playerid);
		    DisablePlayerCheckpoint(playerid);
		}

		if(playerid == gObjectiveGreenPlayer) {
		    gObjectiveGreenPlayer = (-1);
		    SetPlayerToTeamColor(playerid);
		    DisablePlayerCheckpoint(playerid);
		}
	}

	return 1;
}

public SetPlayerTeamFromClass(playerid,classid)
{
	// Set their team number based on the class they selected.
	if(classid == 0 || classid == 1) {
		gTeam[playerid] = TEAM_GREEN;
	} else if(classid == 2 || classid == 3) {
	    gTeam[playerid] = TEAM_BLUE;
	}
}

public SetPlayerToTeamColor(playerid)
{
	if(gTeam[playerid] == TEAM_BLUE) {
		SetPlayerColor(playerid,TEAM_BLUE_COLOR); // blue
	} else if(gTeam[playerid] == TEAM_GREEN) {
	    SetPlayerColor(playerid,TEAM_GREEN_COLOR); // green
	}
}

public OnGameModeExit()
{
	print("GameModeExit()");
	return 1;
}

public OnPlayerConnect(playerid)
{
	GameTextForPlayer(playerid,"~w~SA-MP:~g~LocalYokel~w~:~r~SE",8000,5);
	SendPlayerFormattedText(playerid, "Welcome to Local Yokel: Liberty City, for help type /help.", 0);
	GivePlayerMoney(playerid, 500);
	return 1;
}

public OnPlayerDisconnect(playerid)
{
	printf("OnPlayerDisconnect(%d)", playerid);
	return 1;
}

public OnPlayerCommandText(playerid, cmdtext[])
{
	new cmd[256];
	new idx;

	cmd = strtok(cmdtext, idx);

	if(strcmp(cmd, "/help", true) == 0) {
		SendPlayerFormattedText(playerid,"Local Yokel:Liberty City Coded By Jax and the SA-MP Team, ported to gta:u by dugi.",0);
		SendPlayerFormattedText(playerid,"Type: /objective : to find out what to do in this gamemode.",0);
        return 1;
	}
	if(strcmp(cmd, "/objective", true) == 0) {
		SendPlayerFormattedText(playerid,"The Objective of this gamemode is to steal the other teams flag car, which in",0);
		SendPlayerFormattedText(playerid,"this particular gamemode is a Truck (Linerunner). The first team to capture,",0);
		SendPlayerFormattedText(playerid,"the oppositions truck three times wins.",0);
        return 1;
	}


	// PROCESS OTHER COMMANDS


	return 0;
}

public OnPlayerSpawn(playerid)
{

	SetPlayerToTeamColor(playerid);

	if(gTeam[playerid] == TEAM_BLUE) {
		SetPlayerRandomSpawn(playerid);
		SetVehicleParamsForPlayer(OBJECTIVE_VEHICLE_GREEN,playerid,1,0); // objective; unlocked
		SetVehicleParamsForPlayer(OBJECTIVE_VEHICLE_BLUE,playerid,1,1); // objective; locked

		//SetPlayerWorldBounds(playerid,2444.4185,1687.5696,631.2963,-454.9898);
		GameTextForPlayer(playerid,
		   "Defend the ~b~BLUE ~w~team's ~r~Truck~n~~w~Capture the ~g~GREEN ~w~team's ~r~Truck",
		   6000,5);
	}
	else if(gTeam[playerid] == TEAM_GREEN) {
		SetPlayerRandomSpawn(playerid);
		SetVehicleParamsForPlayer(OBJECTIVE_VEHICLE_BLUE,playerid,1,0); // objective; unlocked
		SetVehicleParamsForPlayer(OBJECTIVE_VEHICLE_GREEN,playerid,1,1); // objective; locked
		//SetPlayerWorldBounds(playerid,2444.4185,1687.5696,631.2963,-454.9898);
		GameTextForPlayer(playerid,
		   "Defend the ~g~GREEN ~w~team's ~r~Truck~n~~w~Capture the ~b~BLUE ~w~team's ~r~Truck",
		   6000,5);
	}
	SetPlayerInterior(playerid,0);

	return 1;
}

public OnPlayerEnterCheckpoint(playerid)
{
 	new playervehicleid = GetPlayerVehicleID(playerid);

 	if(gObjectiveReached) return;

	if(playervehicleid == OBJECTIVE_VEHICLE_GREEN && gTeam[playerid] == TEAM_BLUE)
	{   // Green OBJECTIVE REACHED.
		GameTextForAll("~b~Blue ~w~team has ~r~Scored~w~!!!",5000,5);
		gObjectiveReached = 1;
		SetPlayerScore(playerid,GetPlayerScore(playerid)+5);

		if (gBlueScore < GAME_ROUNDLIMIT)  {
	        gBlueScore++;
  			RemovePlayerFromVehicle(playerid);
	        SetPlayerColor(playerid, TEAM_BLUE_COLOR);
	        SetVehicleToRespawn(OBJECTIVE_VEHICLE_GREEN);
	        gObjectiveReached = 0;
	        }
		else if (gBlueScore == GAME_ROUNDLIMIT)  {
			SetTimer("ExitTheGameMode", 4000, 0); // Set up a timer to exit this mode.
			}
		return;
	}
	else if(playervehicleid == OBJECTIVE_VEHICLE_BLUE && gTeam[playerid] == TEAM_GREEN)
	{   // Blue OBJECTIVE REACHED.
     	GameTextForAll("~g~Green ~w~team has ~r~Scored~w~!!!",5000,5);
	    gObjectiveReached = 1;
	    SetPlayerScore(playerid,GetPlayerScore(playerid)+5);

	    if (gGreenScore < GAME_ROUNDLIMIT)  {
	        gGreenScore++;
	        RemovePlayerFromVehicle(playerid);
	        SetPlayerColor(playerid, TEAM_GREEN_COLOR);
	        SetVehicleToRespawn(OBJECTIVE_VEHICLE_BLUE);
	        gObjectiveReached = 0;
	        }
		else if (gGreenScore == GAME_ROUNDLIMIT)  {
			SetTimer("ExitTheGameMode", 4000, 0); // Set up a timer to exit this mode.
			}
	    return;
	}
}

public ExitTheGameMode()
{
    GameModeExit();
}

public SetPlayerRandomSpawn(playerid)
{

	if(gTeam[playerid] == TEAM_GREEN) {
		new rand = random(sizeof(gTeam1RandomPlayerSpawns));
		SetPlayerPos(playerid, gTeam1RandomPlayerSpawns[rand][0], gTeam1RandomPlayerSpawns[rand][1], gTeam1RandomPlayerSpawns[rand][2]); // Warp the player
		}
	else if(gTeam[playerid] == TEAM_BLUE) {
		new rand = random(sizeof(gTeam2RandomPlayerSpawns));
		SetPlayerPos(playerid, gTeam2RandomPlayerSpawns[rand][0], gTeam2RandomPlayerSpawns[rand][1], gTeam2RandomPlayerSpawns[rand][2]); // Warp the player
		}
	return 1;
}


//------------------------------------------------------------------------------------------------------

public OnPlayerDeath(playerid, killerid, reason)
{
	if(killerid == INVALID_PLAYER_ID) {
        SendDeathMessage(INVALID_PLAYER_ID,playerid,reason);
	} else {
        if(gTeam[killerid] != gTeam[playerid]) {
	    	// Valid kill
	    	SendDeathMessage(killerid,playerid,reason);
			SetPlayerScore(killerid,GetPlayerScore(killerid)+1);
     	}
		else {
		    // Team kill
		    SendDeathMessage(killerid,playerid,reason);
		}
	}
 	return 1;
}

//------------------------------------------------------------------------------------------------------

public SetupPlayerForClassSelection(playerid)
{
	SetPlayerInterior(playerid,14);
	SetPlayerPos(playerid,258.4893,-41.4008,1002.0234);
	SetPlayerFacingAngle(playerid, 180.0);
	SetPlayerCameraPos(playerid,256.0815,-43.0475,1004.0234);
	SetPlayerCameraLookAt(playerid,258.4893,-41.4008,1002.0234);
}

public OnPlayerText(playerid)
{
	printf("OnPlayerText(%d)", playerid);
	return 1;
}

public OnPlayerRequestClass(playerid, classid)
{
	SetupPlayerForClassSelection(playerid);
	SetPlayerTeamFromClass(playerid,classid);

	if(classid == 0 || classid == 1) {
		GameTextForPlayer(playerid,"~g~GREEN ~w~TEAM",1000,5);
	} else if(classid == 2 || classid == 3) {
	    GameTextForPlayer(playerid,"~b~BLUE ~w~TEAM",1000,5);
	}

	return 1;
}

public OnPlayerEnterVehicle(playerid, vehicleid, ispassenger)
{
	printf("OnPlayerEnterVehicle(%d, %d, %d)", playerid, vehicleid, ispassenger);
	return 1;
}

public OnPlayerExitVehicle(playerid, vehicleid)
{
	printf("OnPlayerExitVehicle(%d, %d)", playerid, vehicleid);
	return 1;
}

public OnGameModeInit()
{
	SetGameModeText("LocalYokel~LC");

    UsePlayerPedAnims();
	ShowPlayerMarkers(1);
	ShowNameTags(1);

	// Player Class's
	AddPlayerClass(45,1958.3783,1343.1572,15.3746,269.1425,0,0,31,400,29,400);
	AddPlayerClass(101,1958.3783,1343.1572,15.3746,269.1425,0,0,31,400,29,400);
	AddPlayerClass(44,1958.3783,1343.1572,15.3746,269.1425,0,0,31,400,29,400);
	AddPlayerClass(79,1958.3783,1343.1572,15.3746,269.1425,0,0,31,400,29,400);


	//Uber haxed
	new rand = random(sizeof(gTeam1CapCarSpawns));
	AddStaticVehicle(403,gTeam1CapCarSpawns[rand][0], gTeam1CapCarSpawns[rand][1], gTeam1CapCarSpawns[rand][2], gTeam1CapCarSpawns[rand][3],16,86); //    1
	new rand2 = random(sizeof(gTeam2CapCarSpawns));
	AddStaticVehicle(403,gTeam2CapCarSpawns[rand2][0], gTeam2CapCarSpawns[rand2][1], gTeam2CapCarSpawns[rand2][2], gTeam2CapCarSpawns[rand2][3],53,79); //   2

    AddStaticVehicle(429,-343.9260,961.7240,14.6064,268.5747,86,86); // green team car
	AddStaticVehicle(415,-343.5353,957.7344,14.6979,272.5916,86,86); // green team car
	AddStaticVehicle(558,-343.3405,933.7040,14.5510,359.4689,86,86); // green team car
	AddStaticVehicle(506,-322.8075,953.3930,14.6092,271.3633,86,86); // green team car
	AddStaticVehicle(560,-337.6926,926.8869,14.6239,90.2652,21,86); // green team car


 	AddStaticVehicle(560,66.1790,996.3936,11.4887,270.3481,79,79); // blue team
	AddStaticVehicle(451,75.2839,1012.9329,11.4982,89.8182,79,79); // blue team
	AddStaticVehicle(506,66.4026,1004.2452,11.4918,89.0388,79,79); // blue team
	AddStaticVehicle(429,50.0987,964.2067,11.4690,0.6579,79,79); // blue team
	AddStaticVehicle(558,76.6700,1000.4581,11.4137,90.6837,79,79); // blue team



	AddStaticVehicle(468,-108.3543,1047.4224,14.7969,175.8848,46,46); // random car
	AddStaticVehicle(542,-154.5608,926.3849,14.5970,314.2479,24,118); // random car
	AddStaticVehicle(421,-108.6483,934.2744,14.7348,225.6574,13,1); // random car



	AddVehicleComponent(OBJECTIVE_VEHICLE_GREEN, 1010);
	AddVehicleComponent(OBJECTIVE_VEHICLE_BLUE, 1010);
	AddVehicleComponent(OBJECTIVE_VEHICLE_GREEN, 1096);
	AddVehicleComponent(OBJECTIVE_VEHICLE_BLUE, 1096);

	return 1;
}

public SendPlayerFormattedText(playerid, const str[], define)
{
	new tmpbuf[256];
	format(tmpbuf, sizeof(tmpbuf), str, define);
	SendClientMessage(playerid, 0xFFFF00AA, tmpbuf);
}

public SendAllFormattedText(playerid, const str[], define)
{
	new tmpbuf[256];
	format(tmpbuf, sizeof(tmpbuf), str, define);
	SendClientMessageToAll(0xFFFF00AA, tmpbuf);
}

strtok(const string[], &index)
{
	new length = strlen(string);
	while ((index < length) && (string[index] <= ' '))
	{
		index++;
	}

	new offset = index;
	new result[20];
	while ((index < length) && (string[index] > ' ') && ((index - offset) < (sizeof(result) - 1)))
	{
		result[index - offset] = string[index];
		index++;
	}
	result[index - offset] = EOS;
	return result;
}
