//---------------------------------------------------------
//
// Cop'n'Gangs v2 by kyeman 2006
// ported for GTA United by Sebihunter 2008
//
//---------------------------------------------------------

#include <a_samp>
#include <core>
#include <float>

// Global stuff and defines for our gamemode.

static gTeam[MAX_PLAYERS]; // Tracks the team assignment for each player

#define OBJECTIVE_VEHICLE_GREEN 2
#define OBJECTIVE_VEHICLE_BLUE 1
#define TEAM_GREEN 1
#define TEAM_BLUE 2
#define COLOR_GREY 			0xAFAFAFAA
#define OBJECTIVE_COLOR 0xAA0000FF
#define TEAM_GREEN_COLOR 0x33AA33AA
#define TEAM_BLUE_COLOR 0x3333AAAA

new gObjectiveGreenPlayer=(-1);
new gObjectiveBluePlayer=(-1);
new gObjectiveReached=0;

forward SetPlayerToTeamColor(playerid);
forward SetupPlayerForClassSelection(playerid);
forward SetPlayerTeamFromClass(playerid,classid);
forward ExitTheGameMode();

//---------------------------------------------------------

main()
{
	print("\n----------------------------------");
	print("  Cops'n'Gangs v2 by kyeman 2006\n");
	print("  ported to GTA United by Sebihunter 2008\n");
	print("----------------------------------\n");
}

//---------------------------------------------------------

public OnPlayerStateChange(playerid, newstate, oldstate)
{
	new vehicleid;

	if(newstate == PLAYER_STATE_DRIVER)
	{
		vehicleid = GetPlayerVehicleID(playerid);

		if(gTeam[playerid] == TEAM_GREEN && vehicleid == OBJECTIVE_VEHICLE_GREEN)
		{ // It's the objective vehicle
		    SetPlayerColor(playerid,OBJECTIVE_COLOR);
		    GameTextForPlayer(playerid,"~w~Take the ~r~van ~w~back to the spawn!",3000,5);
		    gObjectiveGreenPlayer = playerid;
		}

		if(gTeam[playerid] == TEAM_BLUE && vehicleid == OBJECTIVE_VEHICLE_BLUE)
		{ // It's the objective vehicle
		    SetPlayerColor(playerid,OBJECTIVE_COLOR);
		    GameTextForPlayer(playerid,"~w~Take the ~r~van ~w~back to the spawn!",3000,5);
		    gObjectiveBluePlayer = playerid;
		}
	}
	else if(newstate == PLAYER_STATE_ONFOOT)
	{
		if(playerid == gObjectiveGreenPlayer) {
		    gObjectiveGreenPlayer = (-1);
		    SetPlayerToTeamColor(playerid);
		}

		if(playerid == gObjectiveBluePlayer) {
		    gObjectiveBluePlayer = (-1);
		    SetPlayerToTeamColor(playerid);
		}
	}

    return 1;
}

//---------------------------------------------------------

public OnGameModeInit()
{
	SetGameModeText("CopsNGangs: LC");

	UsePlayerPedAnims();
	ShowPlayerMarkers(0);
	ShowNameTags(1);
	SetWorldTime(19);

	// GANG CLASSES
	AddPlayerClass(105,-460.5335,1500.5801,8.7751,185.9785,9,0,25,25,32,200);
	AddPlayerClass(106,-460.5335,1500.5801,8.7751,185.9785,42,400,30,100,32,200);
	AddPlayerClass(107,-460.5335,1500.5801,8.7751,185.9785,5,0,30,100,29,200);

 	// POLICE CLASSES
	AddPlayerClass(280,-201.8634,1124.8555,14.9441,90.9029,42,400,31,100,29,200);
	AddPlayerClass(281,-201.8634,1124.8555,14.9441,90.9029,3,0,31,100,29,200);
	AddPlayerClass(284,-201.8634,1124.8555,14.9441,90.9029,3,0,25,25,32,200);

	// OBJECTIVE VEHICLES
    AddStaticVehicle(609,-490.5971,1489.7709,8.9951,3.3450,114,1); // gr objective van
    AddStaticVehicle(609,-199.1326,1110.4078,15.1222,356.6814,0,1); // bl objective van

    // GANGS VEHICLES
    AddStaticVehicle(560,-486.8235,1489.0338,8.4294,3.9367,9,39); // Robbers car (sultan)
    AddStaticVehicle(560,-482.6607,1489.2131,8.3319,3.1705,17,1); // Robbers car (sultan)
    AddStaticVehicle(560,-478.9793,1489.2786,8.3133,3.8227,9,39); // Robbers car (sultan)
    AddStaticVehicle(560,-473.9541,1489.3298,8.3965,0.2535,17,1); // Robbers car (sultan)

	// COPS VEHICLES
    AddStaticVehicle(596,-211.2722,1160.2928,14.6624,178.5691,0,1); // Police Car (LSPD)
    AddStaticVehicle(596,-204.9340,1160.6375,14.6513,176.4668,0,1); // Police Car (LSPD)
    AddStaticVehicle(596,-211.1160,1109.6191,14.6617,2.5693,0,1); // Police Car (LSPD)
    AddStaticVehicle(596,-206.9621,1109.6797,14.6649,2.4006,0,1); // Police Car (LSPD)
    AddStaticVehicle(596,-203.2096,1110.0220,14.6765,355.7207,0,1); // Police Car (LSPD)

	return 1;
}

//---------------------------------------------------------

public OnPlayerConnect(playerid)
{
	SetPlayerColor(playerid,0x888888FF);
	new str[128], PlayerName[128];
	
	GetPlayerName(playerid, PlayerName, sizeof(PlayerName));
	format(str, sizeof(str), "SERVER: %s(id:%i) has joined the server.", PlayerName, playerid);
	SendClientMessageToAll(COLOR_GREY, str);
    GameTextForPlayer(playerid,"~w~SA-MP: ~r~Vice City Golfers",5000,5);
	return 1;
}

public OnPlayerDisconnect(playerid, reason)
{
    new str[128], PlayerName[128];
    GetPlayerName(playerid, PlayerName, sizeof(PlayerName));
	switch(reason)
	{
	    case 0: format(str, sizeof(str), "crashed");
	    case 1: format(str, sizeof(str), "left");
	    case 2: format(str, sizeof(str), "got kicked / banned");
	}
    format(str, sizeof(str), "SERVER: %s(id:%i) has %s.", PlayerName, playerid, str);
	SendClientMessage(playerid, COLOR_GREY, str);
	return 1;
}

//---------------------------------------------------------

public SetupPlayerForClassSelection(playerid)
{
        SetPlayerInterior(playerid,0);
        SetPlayerPos(playerid,2079.4976,-365.7190,9.0355);
        SetPlayerFacingAngle(playerid, 283.0);
        SetPlayerCameraPos(playerid,2090.0,-364.3,11.5);
        SetPlayerCameraLookAt(playerid,2079.4976,-365.7190,9.0355);
}

//---------------------------------------------------------

public SetPlayerTeamFromClass(playerid,classid)
{
	// Set their team number based on the class they selected.
	if(classid == 0 || classid == 1 || classid == 2) {
		gTeam[playerid] = TEAM_GREEN;
	} else if(classid == 3 || classid == 4 || classid == 5) {
	    gTeam[playerid] = TEAM_BLUE;
	}
}

//---------------------------------------------------------

public SetPlayerToTeamColor(playerid)
{
	if(gTeam[playerid] == TEAM_GREEN) {
		SetPlayerColor(playerid,TEAM_GREEN_COLOR); // green
	} else if(gTeam[playerid] == TEAM_BLUE) {
	    SetPlayerColor(playerid,TEAM_BLUE_COLOR); // blue
	}
}

//---------------------------------------------------------

public OnPlayerRequestClass(playerid, classid)
{
	SetupPlayerForClassSelection(playerid);
	SetPlayerTeamFromClass(playerid,classid);

	if(classid == 0 || classid == 1 || classid == 2) {
		GameTextForPlayer(playerid,"~g~GANG ~w~TEAM",1000,5);
	} else if(classid == 3 || classid == 4 || classid == 5) {
	    GameTextForPlayer(playerid,"~b~COP ~w~TEAM",1000,5);
	}

	return 1;
}

//---------------------------------------------------------

public OnPlayerSpawn(playerid)
{
	SetPlayerToTeamColor(playerid);
	SetPlayerInterior(playerid,0);

	if(gTeam[playerid] == TEAM_GREEN) {
	    SetVehicleParamsForPlayer(OBJECTIVE_VEHICLE_GREEN,playerid,1,0); // objective; unlocked
		SetVehicleParamsForPlayer(OBJECTIVE_VEHICLE_BLUE,playerid,1,1); // objective; locked
	    SetPlayerCheckpoint(playerid,-465.5241,1496.7750,8.4181,5.0);
	    GameTextForPlayer(playerid,
		   "Defend the ~g~GANG ~w~team's ~r~Van~n~~w~Capture the ~b~COP ~w~team's ~r~Van",
		   6000,5);
	}
	else if(gTeam[playerid] == TEAM_BLUE) {
		SetVehicleParamsForPlayer(OBJECTIVE_VEHICLE_BLUE,playerid,1,0); // objective; unlocked
		SetVehicleParamsForPlayer(OBJECTIVE_VEHICLE_GREEN,playerid,1,1); // objective; locked
	    SetPlayerCheckpoint(playerid,-178.9186,1116.5862,18.8600,5.0);
	    GameTextForPlayer(playerid,
		   "Defend the ~b~COP ~w~team's ~r~Van~n~~w~Capture the ~g~GANG ~w~team's ~r~Van",
		   6000,5);
	}

	return 1;
}

//---------------------------------------------------------

public OnPlayerEnterCheckpoint(playerid)
{
 	new playervehicleid = GetPlayerVehicleID(playerid);

 	if(gObjectiveReached) return;

	if(playervehicleid == OBJECTIVE_VEHICLE_GREEN && gTeam[playerid] == TEAM_GREEN)
	{   // Green OBJECTIVE REACHED.
	    GameTextForAll("~g~GANG ~w~team wins!",3000,5);
	    gObjectiveReached = 1;
	    SetPlayerScore(playerid,GetPlayerScore(playerid)+5);
	    SetTimer("ExitTheGameMode", 4000, 0); // Set up a timer to exit this mode.
	    return;
	}
	else if(playervehicleid == OBJECTIVE_VEHICLE_BLUE && gTeam[playerid] == TEAM_BLUE)
	{   // Blue OBJECTIVE REACHED.
	    GameTextForAll("~b~COP ~w~team wins!",3000,5);
	    gObjectiveReached = 1;
	    SetPlayerScore(playerid,GetPlayerScore(playerid)+5);
	    SetTimer("ExitTheGameMode", 4000, 0); // Set up a timer to exit this mode.
	    return;
	}
}

//---------------------------------------------------------

public OnPlayerText(playerid, text[])
{
	if(text[0] == '!')
	{
	    new string[128], PlayerName[128];
   		GetPlayerName(playerid, PlayerName, sizeof(PlayerName));
   		
	    format(string, sizeof string, "GANG <%s>: %s", PlayerName, text[1]);
	    
	    for(new i; i < MAX_PLAYERS; i++)
	    {
	        if(gTeam[i] == gTeam[playerid])
	        {
	            SendClientMessage(i, COLOR_GREY, string);
			}
		}
 		return false;
	}
	return true;
}


//---------------------------------------------------------

public ExitTheGameMode()
{
    SendRconCommand("changemode lccng");
}

//---------------------------------------------------------

public OnPlayerDeath(playerid, killerid, reason)
{
	if(killerid == INVALID_PLAYER_ID) {
        SendDeathMessage(INVALID_PLAYER_ID,playerid,reason);
	} else {
        if(gTeam[killerid] != gTeam[playerid]) {
	    	// Valid kill
	    	SendDeathMessage(killerid,playerid,reason);
			SetPlayerScore(killerid,GetPlayerScore(killerid)+1);
     	}
		else {
		    // Team kill
		    SetPlayerScore(killerid,GetPlayerScore(killerid)+1);
		}
	}
 	return 1;
}

//---------------------------------
