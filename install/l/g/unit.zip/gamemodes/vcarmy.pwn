//---------------------------------------------------------
//
// Army Break-in. Break into the Army VC.
//
//---------------------------------------------------------

#include <a_samp>

#define TEAM_ATTACK 1
#define TEAM_DEFENCE 2
#define CHECKPOINT_NONE 0
#define CHECKPOINT_ARMY 1
#define DEFENCE_WIN 0
#define ATTACK_WIN 1
#define COLOR_GREY 0xAFAFAFAA
#define COLOR_GREEN 0x33AA33AA
#define COLOR_RED 0xAA3333AA
#define COLOR_YELLOW 0xFFFF00AA

forward DefenceWin();
forward GameModeExitFunc();

new gTeam[MAX_PLAYERS];
new gPlayerClass[MAX_PLAYERS];
new gPlayerCheckpointStatus[MAX_PLAYERS];
new gRoundTimer;

// If the army defend the lab for this amount of time, they win.
//new gRoundTime = 1200000;					// Round time - 20 mins
//new gRoundTime = 900000;					// Round time - 15 mins
new gRoundTime = 600000;					// Round time - 10 mins
//new gRoundTime = 300000;					// Round time - 5 mins
//new gRoundTime = 120000;					// Round time - 2 mins
//new gRoundTime = 60000;					// Round time - 1 min
//---------------------------------------------------------
main(){
	print("\n----------------------------------");
	print("  Area 51 break-in\n   by Mike (2006)");
	print("----------------------------------\n");
}
//---------------------------------------------------------
public OnGameModeInit(){
	SetGameModeText("Army Break-in [GTAU-MP]");
	ShowNameTags(1);
	ShowPlayerMarkers(0);
	SetWorldTime(0);
	AddPlayerClass(111,375.0303,-1285.8297,9.3242,64.1073, 3, 0, 23, 1000, 25, 100); // Mafia dude, andromeda
	AddPlayerClass(287,313.4856,-1096.1229,9.3275,146.4915, 4, 0, 32, 1000, 31, 5000); // Army
	gRoundTimer = SetTimer("DefenceWin", gRoundTime, 0);
	return 1;
}
//---------------------------------------------------------
public DefenceWin() {
	EndTheRound(DEFENCE_WIN);
}
//---------------------------------------------------------
public OnPlayerConnect(playerid){
	GameTextForPlayer(playerid,"~w~GTAU-MP Army Break-in!",4000,3);
	SetPlayerColor(playerid,COLOR_GREY);
	return 1;

}
//---------------------------------------------------------
public OnPlayerRequestClass(playerid, classid){
	if(classid == 0) {
		gTeam[playerid] = TEAM_ATTACK;
	} else if(classid == 1) {
	    gTeam[playerid] = TEAM_DEFENCE;
	}
	SetPlayerInterior(playerid,0);
	SetPlayerFacingAngle(playerid,269.5026);
	SetPlayerPos(playerid,305.8018,-1237.8478,24.2105);
	SetPlayerCameraPos(playerid,307.0,-1237.8478,25.0);
	SetPlayerCameraLookAt(playerid,305.8018,-1237.8478,25.0);
	gPlayerClass[playerid] = classid;
	switch (classid) {
		case 0:{
			GameTextForPlayer(playerid, "~r~Attack", 1000, 3);
		}
		case 1:{
			GameTextForPlayer(playerid, "~g~Defence", 1000, 3);
		}
	}
	return 1;
}
//---------------------------------------------------------
public OnPlayerSpawn(playerid){
	if(gTeam[playerid] == TEAM_ATTACK) {
		SetPlayerColor(playerid,COLOR_RED); // Red
	} else if(gTeam[playerid] == TEAM_DEFENCE) {
	    SetPlayerColor(playerid,COLOR_GREEN); // Green
	}
	//SetPlayerWorldBounds(playerid, 388.6190, -7.9993, 2147.0618, 1655.8849);
	switch (gPlayerClass[playerid]) {
	    case 0:{
			 	gPlayerCheckpointStatus[playerid] = CHECKPOINT_ARMY;
				SetPlayerCheckpoint(playerid,278.7817,-1050.5878,9.3275,5.0);
				GameTextForPlayer(playerid, "~r~Attack the Army Base", 2000, 5);
				SetPlayerInterior(playerid,0);
		}case 1:{
			 	gPlayerCheckpointStatus[playerid] = CHECKPOINT_NONE;
				GameTextForPlayer(playerid, "~r~Defend the Army Base", 2000, 5);
				SetPlayerInterior(playerid,0);
			}
	}
	return 1;
}
//---------------------------------------------------------
public OnPlayerEnterCheckpoint(playerid) {
	switch (gPlayerCheckpointStatus[playerid]) {
		case CHECKPOINT_ARMY:{
			DisablePlayerCheckpoint(playerid);
			gPlayerCheckpointStatus[playerid] = CHECKPOINT_NONE;
			EndTheRound(ATTACK_WIN);
		}
  		default:{
			DisablePlayerCheckpoint(playerid);
		}
	}
	return 1;
}
//---------------------------------------------------------
public OnPlayerDeath(playerid, killerid, reason){
	if (killerid != INVALID_PLAYER_ID){
		if (gTeam[playerid] == gTeam[killerid]){
			SetPlayerScore(killerid, GetPlayerScore(killerid) - 1);
		}else{
			SetPlayerScore(killerid, GetPlayerScore(killerid) + 1);
		}
	}
	SendDeathMessage(killerid, playerid, reason);
	DisablePlayerCheckpoint(playerid);
	gPlayerCheckpointStatus[playerid] = CHECKPOINT_NONE;
	SetPlayerColor(playerid,COLOR_GREY);
 	return 1;

}
//---------------------------------------------------------
stock EndTheRound(winner) {
	switch (winner){
	    case ATTACK_WIN:{GameTextForAll("The attackers broke into Army Base.", 2000, 5); KillTimer(gRoundTimer);}
	    case DEFENCE_WIN:{GameTextForAll("Army Base was successfully defended.", 2000, 5);}
	}
	SetTimer("GameModeExitFunc", 5000, 0);
}
//---------------------------------------------------------
public GameModeExitFunc(){
	SendRconCommand("GMX");
}
//---------------------------------------------------------
