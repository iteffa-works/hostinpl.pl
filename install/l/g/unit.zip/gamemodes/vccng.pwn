//---------------------------------------------------------
//
// Cop'n'Gangs v1 By [M]z00H
// Modified by Brendan Thomson
//Please note that it's my first [GM]. DONT REMOVE CREDITS !!
//---------------------------------------------------------

#include <a_samp>
#include <core>
#include <float>

// Global stuff and defines for our gamemode.

static gTeam[MAX_PLAYERS]; // Tracks the team assignment for each player

#define OBJECTIVE_VEHICLE_RED 2
#define OBJECTIVE_VEHICLE_BLUE 1
#define TEAM_RED 1
#define TEAM_BLUE 2
#define OBJECTIVE_COLOR 0xAA0000FF
#define TEAM_RED_COLOR 0xAA3333AA
#define TEAM_BLUE_COLOR 0x3333AAAA
#define COLOR_YELLOW 0xFFFF00AA
#define COLOR_GRAD2 0xBFC0C2FF
#define COLOR_GREY 0xBFC0C2FF

new gObjectiveREDPlayer=(-1);
new gObjectiveBluePlayer=(-1);
new gObjectiveReached=0;

forward SetPlayerToTeamColor(playerid);
forward SetupPlayerForClassSelection(playerid);
forward SetPlayerTeamFromClass(playerid,classid);
forward ExitTheGameMode();

//---------------------------------------------------------

main()
{
	print("\n----------------------------------");
	print(" Cops 'n Gangs by [M]z00H");
	print(" Modified By Brendan Thomson");
	print("----------------------------------\n");
}

//---------------------------------------------------------

public OnPlayerStateChange(playerid, newstate, oldstate)
{
	new vehicleid;

	if(newstate == PLAYER_STATE_DRIVER)
	{
		vehicleid = GetPlayerVehicleID(playerid);

		if(gTeam[playerid] == TEAM_RED && vehicleid == OBJECTIVE_VEHICLE_RED)
		{ // It's the objective vehicle
		    SetPlayerColor(playerid,OBJECTIVE_COLOR);
		    GameTextForPlayer(playerid,"~w~Take the ~b~car ~w~to the checkpoint!",3000,5);
		    gObjectiveREDPlayer = playerid;
		}

		if(gTeam[playerid] == TEAM_BLUE && vehicleid == OBJECTIVE_VEHICLE_BLUE)
		{ // It's the objective vehicle
		    SetPlayerColor(playerid,OBJECTIVE_COLOR);
		    GameTextForPlayer(playerid,"~w~Take the ~r~car ~w~to the checkpoint!",3000,5);
		    gObjectiveBluePlayer = playerid;
		}
	}
	else if(newstate == PLAYER_STATE_ONFOOT)
	{
		if(playerid == gObjectiveREDPlayer) {
		    gObjectiveREDPlayer = (-1);
		    SetPlayerToTeamColor(playerid);
		}

		if(playerid == gObjectiveBluePlayer) {
		    gObjectiveBluePlayer = (-1);
		    SetPlayerToTeamColor(playerid);
		}
	}

    return 1;
}

//---------------------------------------------------------

public OnGameModeInit()
{
	SetGameModeText("CopsNGangs: VC");

	ShowPlayerMarkers(0);
	ShowNameTags(1);
	SetWorldTime(12);

	// GANG CLASSES
	AddPlayerClass(29,1621.3030,-1545.6938,20.2896,358.0107,24,200,25,50,31,300); // gangspawn

 	// POLICE CLASSES
	AddPlayerClass(280,2360.2778,-1448.9825,6.7855,139.2241,24,200,25,50,31,300); // PoliceSpawn

	// OBJECTIVE VEHICLES
 	AddStaticVehicle(428,1621.1481,-1488.5746,11.4478,0.1413,1,0); // cops securica Located at Gang HQ
    AddStaticVehicle(428,2351.5889,-1443.3447,6.5816,140.0024,1,3); // Gangs securica Located at Police HQ

    // GANGS VEHICLES
	AddStaticVehicle(560,1649.3347,-1486.4325,6.9534,88.8285,73,37); // GangCar1
	AddStaticVehicle(560,1640.3035,-1495.1094,6.9296,1.7449,73,37); // GangCar2
	AddStaticVehicle(560,1644.0460,-1493.9761,6.9298,358.8694,73,37); // GangCar3
	AddStaticVehicle(560,1636.1411,-1485.0540,6.9263,1.0120,73,37); // GangCar4
	AddStaticVehicle(560,1634.3450,-1478.9443,6.9262,2.3759,73,37); // GangCar5
	AddStaticVehicle(560,1651.6204,-1476.9581,6.9256,88.5591,73,37); // GangCar6
	AddStaticVehicle(560,1605.6428,-1486.0382,6.9424,0.2508,73,37); // GangCar7
	AddStaticVehicle(560,1609.5573,-1479.3304,6.9278,359.7138,73,37); // GangCar8
	AddStaticVehicle(560,1593.6426,-1486.5530,6.9736,272.9138,73,37); // GangCar9

	// COPS VEHICLES
	AddStaticVehicle(597,2372.0774,-1476.1493,6.6383,319.7061,4,84); // PoliceCar 1
	AddStaticVehicle(597,2369.4358,-1473.6840,6.6005,320.3636,4,84); // PoliceCar 2
	AddStaticVehicle(597,2366.6287,-1471.5662,6.6496,317.5456,4,84); // PoliceCar 3
	AddStaticVehicle(597,2363.9275,-1469.1278,6.5999,319.5357,4,84); // PoliceCar 4
	AddStaticVehicle(597,2360.9771,-1466.7063,6.6001,318.9687,4,84); // PoliceCar 5
	AddStaticVehicle(597,2358.2341,-1464.4689,6.6424,320.3773,4,84); // PoliceCar 6
	AddStaticVehicle(597,2355.4175,-1462.0225,6.6022,320.5502,4,84); // PoliceCar 7
	AddStaticVehicle(597,2352.9121,-1459.9005,6.5985,318.5195,4,84); // PoliceCar 8
	AddStaticVehicle(597,2350.1362,-1457.5702,6.6153,320.1835,4,84); // PoliceCar 9

	return 1;
}

//---------------------------------------------------------

public OnPlayerConnect(playerid)
{
	SetPlayerColor(playerid,0xAFAFAFAA);
	GameTextForPlayer(playerid,"~r~Cop's and ~b~Gangs!",2000,5);
	SendClientMessage(playerid, COLOR_GRAD2, " Cops 'n Gangs by Brendan_Thomson");
	SendClientMessage(playerid, COLOR_GRAD2, " Objective: Steal the enemies truck and take it to the checkpoint.");
	return 1;
}

//---------------------------------------------------------

public SetupPlayerForClassSelection(playerid)
{
	SetPlayerInterior(playerid,0);
	SetPlayerPos(playerid,2105.7695,-351.3560,10.6444);
    SetPlayerCameraPos(playerid,2105.7695,-346.3560,10.6444);
	SetPlayerCameraLookAt(playerid,2105.7695,-361.3560,10.6444);
	SetPlayerFacingAngle(playerid,0.0);
}

//---------------------------------------------------------

public SetPlayerTeamFromClass(playerid,classid)
{
	// Set their team number based on the class they selected.
	if(classid == 0) {
		gTeam[playerid] = TEAM_RED;
	} else if(classid == 1) {
	    gTeam[playerid] = TEAM_BLUE;
	}
}

//---------------------------------------------------------

public SetPlayerToTeamColor(playerid)
{
	if(gTeam[playerid] == TEAM_RED) {
		SetPlayerColor(playerid,TEAM_RED_COLOR); // RED
	} else if(gTeam[playerid] == TEAM_BLUE) {
	    SetPlayerColor(playerid,TEAM_BLUE_COLOR); // blue
	}
}

//---------------------------------------------------------

public OnPlayerRequestClass(playerid, classid)
{
	SetupPlayerForClassSelection(playerid);
	SetPlayerTeamFromClass(playerid,classid);

	if(classid == 0) {
		GameTextForPlayer(playerid,"~r~Gang ~w~TEAM",1000,5);
	} else if(classid == 1) {
	    GameTextForPlayer(playerid,"~b~Cop ~w~TEAM",1000,5);
	}

	return 1;
}

//---------------------------------------------------------

public OnPlayerSpawn(playerid)
{
	SetPlayerToTeamColor(playerid);
	SetPlayerInterior(playerid,0);

	if(gTeam[playerid] == TEAM_RED) {
		SetPlayerPos(playerid, 1621.3030,-1545.6938,20.2896);
		SetPlayerFacingAngle(playerid, 358.0107);
		SetVehicleParamsForPlayer(OBJECTIVE_VEHICLE_RED,playerid,1,0); // objective; unlocked
		SetVehicleParamsForPlayer(OBJECTIVE_VEHICLE_BLUE,playerid,1,1); // objective; locked
	    SetPlayerCheckpoint(playerid,1589.3772,-1469.3054,7.2399,5.0);
	    GameTextForPlayer(playerid,"Defend the ~r~Gang ~w~team's ~r~Car~n~~w~Capture the ~b~Cop ~w~team's ~b~Car",6000,5);
	}
	else if(gTeam[playerid] == TEAM_BLUE) {
	    SetPlayerPos(playerid, 2360.2778,-1448.9825,6.7855);
		SetPlayerFacingAngle(playerid, 139.2241);
		SetVehicleParamsForPlayer(OBJECTIVE_VEHICLE_BLUE,playerid,1,0); // objective; unlocked
		SetVehicleParamsForPlayer(OBJECTIVE_VEHICLE_RED,playerid,1,1); // objective; locked
	    SetPlayerCheckpoint(playerid,2380.1685,-1467.1100,6.7855,7.0);
	    GameTextForPlayer(playerid,"Defend the ~b~Cop ~w~team's ~b~Car~n~~w~Capture the ~r~Gang ~w~team's ~r~Car",6000,5);
	}

	return 1;
}

//---------------------------------------------------------

public OnPlayerEnterCheckpoint(playerid)
{
 	new playervehicleid = GetPlayerVehicleID(playerid);

 	if(gObjectiveReached) return 1;

	if(playervehicleid == OBJECTIVE_VEHICLE_RED && gTeam[playerid] == TEAM_RED)
	{   // RED OBJECTIVE REACHED.
	    GameTextForAll("~r~Gangs ~w~team wins!",3000,5);
	    gObjectiveReached = 1;
	    SetPlayerScore(playerid,GetPlayerScore(playerid)+5);
		SetVehicleToRespawn(GetPlayerVehicleID(playerid));
	    if(GetPlayerScore(playerid) == 50)
	    {
	    	SetTimer("ExitTheGameMode", 2000, 0);
		}
	    return 1;
	}
	else if(playervehicleid == OBJECTIVE_VEHICLE_BLUE && gTeam[playerid] == TEAM_BLUE)
	{   // Blue OBJECTIVE REACHED.
	    GameTextForAll("~b~Cop's ~w~team wins!",3000,5);
	    gObjectiveReached = 1;
	    SetPlayerScore(playerid,GetPlayerScore(playerid)+5);
	    SetVehicleToRespawn(GetPlayerVehicleID(playerid));
	    if(GetPlayerScore(playerid) == 50)
	    {
	    	SetTimer("ExitTheGameMode", 2000, 0);
		}
	    return 1;
	}
	return 0;
}

//---------------------------------------------------------

public ExitTheGameMode()
{
    SendRconCommand("gmx");
}

//---------------------------------------------------------

public OnPlayerDeath(playerid, killerid, reason)
{
	if(killerid == INVALID_PLAYER_ID) {
        SendDeathMessage(INVALID_PLAYER_ID,playerid,reason);
	} else {
        if(gTeam[killerid] != gTeam[playerid]) {
	    	// Valid kill
	    	SendDeathMessage(killerid,playerid,reason);
			SetPlayerScore(killerid,GetPlayerScore(killerid)+1);
     	}
		else {
		    // Team kill
		    SetPlayerScore(killerid,GetPlayerScore(killerid)-1);
		}
	}
 	return 1;
}

//---------------------------------

public OnPlayerCommandText(playerid, cmdtext[])
{
	new cmd[256];
	new idx;
	cmd = strtok(cmdtext, idx);
	if(strcmp(cmd, "/kill", true) == 0)
	{
		SendClientMessage(playerid, COLOR_GRAD2, "You have committed suicide");
	    SetPlayerHealth(playerid, 0.0);
	    return 1;
	}
	return 0;
}

strtok(const string[], &index)
{
		new length = strlen(string);
		while ((index < length) && (string[index] <= ' '))
	{
	index++;
	}
		new offset = index;
		new result[20];
		while ((index < length) && (string[index] > ' ') && ((index - offset) < (sizeof(result) - 1)))
	{
		result[index - offset] = string[index];
		index++;
	}
		result[index - offset] = EOS;
		return result;
}
