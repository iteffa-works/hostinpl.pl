//------------------------------------------------------------------------------
// Shoreside Vale. A Team Deathmatch Script for GTA-U
// Orginally,
// San Fierro TDM. A Team Deathmtach script for SA-MP 0.1
//
//------------------------------------------------------------------------------

#include <a_samp>
#include <core>
#include <float>

//Global stuff and defines for our gamemode
static gTeam[MAX_PLAYERS]; // Tracks the team assignment for each player
new gPlayerClass[MAX_PLAYERS];

//Color Defines
#define COLOR_GREY 0xAFAFAFAA
#define COLOR_GREEN 0x33AA33AA
#define COLOR_RED 0xAA3333AA
#define COLOR_YELLOW 0xFFFF00AA
#define COLOR_PINK 0xFF66FFAA
#define COLOR_BLUE 0x0000BBAA
#define COLOR_LIGHTBLUE 0x33CCFFAA
#define COLOR_DARKRED 0x660000AA
#define COLOR_ORANGE 0xFF9900AA

//Team Defines
#define TEAM_PILOT 0
#define TEAM_WORKER 1
#define TEAM_RICH 2
#define TEAM_POLICE 3
#define TEAM_CIVILIAN 4
#define TEAM_NOODLE 5
#define TEAM_TAXI 6



// Round duration
new gRoundTime = 0;
//new gRoundTime = 3600000; // 60 mins
//new gRoundTime = 900000; //15 mins
//new gRoundTime = 300000; // 5 mins

forward SetupPlayerForClassSelection(playerid);
forward GameModeExitFunc();

//------------------------------------------------------------------------------
main()
{
	print("\n----------------------------------");
	print("  SVTDM by Lon (2008)\n");
	print("  Based off SFTDM by Cam (2006)\n");
	print("----------------------------------\n");
}

//------------------------------------------------------------------------------
public OnPlayerCommandText(playerid, cmdtext[])
{
	new cmd[256];
	new idx;
	cmd = strtok(cmdtext, idx);

	if(strcmp(cmd, "/kill", true) == 0) {
		SetPlayerHealth(playerid, 0);
    	return 1;
	}
	return 1;
}

public OnGameModeInit()
{
	AllowInteriorWeapons(1);
	UsePlayerPedAnims();
	SetGameModeText("Shoreside Vale TDM");
	SetTeamCount(7);
	ShowNameTags(1);
	ShowPlayerMarkers(1);
	SetWorldTime(18);


//SPAWNS - Shoreside Vale
	AddPlayerClass(255,-2437.0313,1145.6721,11.0766,88.4148,24,34,30,180,16,12); // Pilot
	AddPlayerClass(260,-2433.4426,1769.0198,48.8380,93.6866,22,68,31,250,32,250); // Worker
	AddPlayerClass(147,-1730.5574,2097.0200,63.4922,180.9465,24,34,27,34,28,250); // Rich
	AddPlayerClass(280,-2606.8921,1755.1625,58.8540,89.5589,24,34,31,250,29,180); // LCPD
    AddPlayerClass(188,-2015.0122,1810.6444,18.8975,169.7792,18,12,30,180,25,20); // civi
	AddPlayerClass(118,-2374.1387,1608.6458,33.7272,126.2783,32,250,24,34,18,12); // noodle
	AddPlayerClass(262,-2118.0942,1255.7968,11.2992,272.4321,25,20,24,34,18,12); // taxi
//VEHICLES - Shoreside Vale
	AddStaticVehicle(596,-2585.0857,1776.5776,58.6857,89.3773,0,1); // lcpd
	AddStaticVehicle(422,-2454.8835,1764.7747,48.8254,181.2350,101,25); // bobcat-worker
	AddStaticVehicle(422,-2459.3096,1764.8938,48.8316,181.4306,111,31); // bobcat-worker
	AddStaticVehicle(440,-2442.5366,1772.3588,48.9608,180.4963,32,32); // rumpo-worker
	AddStaticVehicle(440,-2436.8591,1772.3291,48.9579,181.7951,110,110); // rumpo-worker
	AddStaticVehicle(422,-2464.4575,1765.0116,48.8207,181.6177,113,36); // bobcat-worker
	AddStaticVehicle(440,-2469.3887,1765.7506,48.9502,185.3167,66,66); // rumpo-worker
//	AddStaticVehicle(447,-2509.0608,1139.5720,11.0926,264.7872,75,2); // SEASPARROW (REMOVED)
	AddStaticVehicle(447,-2509.4456,1128.8328,11.0874,268.8690,75,2); // Sparrow-pilot
	AddStaticVehicle(519,-2452.3591,1091.7666,11.9949,90.1804,1,1); // shamal-pilot
	AddStaticVehicle(519,-2451.4600,1121.9155,11.9984,89.5188,1,1); // shamal-pilot
	AddStaticVehicle(593,-2507.8027,1153.4430,11.5366,265.8759,58,8); // dodo-pilot
	AddStaticVehicle(511,-2481.1680,1042.3105,12.4512,0.1897,4,90); // Beagle-pilot
	AddStaticVehicle(511,-2424.8315,1059.9191,12.4497,90.7043,7,68); // beagle-pilot
	AddStaticVehicle(485,-2450.8767,1097.6616,10.7351,88.5088,1,74); // baggage-pilot
	AddStaticVehicle(422,-2440.7576,1105.8481,11.0617,357.1822,97,25); // bobcat
	AddStaticVehicle(451,-1743.6926,2095.7883,62.6296,179.7492,125,125); // tursmo-rich
	AddStaticVehicle(451,-1720.7084,2096.6118,62.6308,181.5077,125,125); // rich-turismo
	AddStaticVehicle(506,-1732.4745,2073.3921,62.3270,191.6072,6,6); // rich-supergt
	AddStaticVehicle(506,-1740.8213,2079.1199,62.2875,274.1505,7,7); // rich-supergt
	AddStaticVehicle(429,-1753.4961,2092.9414,62.6019,260.4788,13,13); // rich-banshee
	AddStaticVehicle(429,-1708.9528,2091.7969,62.5399,90.0123,14,14); // rich-banshee
	AddStaticVehicle(487,-1726.3732,2086.7964,63.4307,180.5953,29,42); // rich-maverick
	AddStaticVehicle(405,-1710.2670,2062.9763,61.0249,169.4538,24,1); // sentenial-rich
	AddStaticVehicle(405,-1721.5126,2057.5701,61.0475,236.5092,36,1); // rich-sentienal
	AddStaticVehicle(506,-1718.5072,2074.3911,62.0097,172.9773,52,52); // supergt
	AddStaticVehicle(411,-1712.7583,2082.6318,62.0864,120.7820,64,1); // rich-infernus
	AddStaticVehicle(539,-1706.7509,2057.8098,60.3292,191.5457,86,70); // rich-vortex
	AddStaticVehicle(596,-2619.8774,1757.0258,58.5657,153.3765,0,1); // lcpd-car
	AddStaticVehicle(596,-2602.4148,1782.8241,58.7551,179.8315,0,1); // lcpd-car
	AddStaticVehicle(596,-2596.2683,1782.5479,58.7420,179.8920,0,1); // lcpd-car
	AddStaticVehicle(596,-2589.9851,1782.5868,58.6657,180.0585,0,1); // lcpd-car
	AddStaticVehicle(596,-2608.3381,1761.7050,58.6502,179.6073,0,1); // lcpd-car
	AddStaticVehicle(560,-2381.3467,1610.6747,33.4294,135.7406,21,1); // sultan-noodle
	AddStaticVehicle(440,-2387.6914,1617.3386,33.8323,135.1212,84,84); // noodle-rumpo
	AddStaticVehicle(440,-2394.1499,1624.3021,33.8270,136.0222,84,84); // rumpo-noodle
	AddStaticVehicle(440,-2390.6699,1593.9703,33.8502,116.6791,84,84); // rumpo-noodle
	AddStaticVehicle(440,-2395.5696,1604.3126,33.8566,294.4047,84,84); // noodle-rumpo
	AddStaticVehicle(440,-2400.5615,1614.0784,33.8230,120.6764,84,84); // noodle-rumpo
	AddStaticVehicle(440,-2395.8054,1627.6870,33.8467,224.0819,84,84); // noodle-rumpo
	AddStaticVehicle(440,-2363.1348,1599.2206,33.8201,269.8223,84,84); // rumpo-noodle
	AddStaticVehicle(560,-1978.9009,1759.6792,18.5370,89.1467,17,1); // civi-sultan
	AddStaticVehicle(412,-1980.0601,1768.7463,18.6691,90.4679,25,8); // civi-voodoo
	AddStaticVehicle(496,-2005.6194,1773.9956,18.5481,177.3575,66,72); // blista-civi
	AddStaticVehicle(405,-2007.8551,1756.2307,18.6995,270.6185,40,1); // sentinel-civi
	AddStaticVehicle(496,-2008.1328,1761.8251,18.5407,89.3812,53,56); // blista-civi
	AddStaticVehicle(559,-2008.5001,1773.8822,18.4880,180.0456,58,8); // jester-civi
	AddStaticVehicle(422,-1979.0652,1764.3048,18.8226,90.8633,83,57); // bobcat-civi
	AddStaticVehicle(562,-1994.8074,1773.4539,18.4905,180.6526,35,1); // elegy-civi
	AddStaticVehicle(562,-2008.4022,1748.1478,18.3995,87.0929,35,1); // elegy-civi
	AddStaticVehicle(542,-1970.0665,1760.4829,18.4839,0.2665,24,118); // clover-civi
	AddStaticVehicle(416,-2597.0928,1703.6116,58.7939,89.8099,1,3); // Ambulance
	AddStaticVehicle(475,-2415.5996,1924.2657,50.8560,27.1032,9,39); // sabre
	AddStaticVehicle(443,-2409.7488,1872.7643,49.5136,27.3360,20,1); // packer
	AddStaticVehicle(491,-2273.8499,1942.6315,48.5029,297.2799,71,72); // virgo
	AddStaticVehicle(492,-2323.3867,1938.6396,48.5300,114.3802,77,26); // greenwood
	AddStaticVehicle(492,-2246.7332,1977.0494,48.5292,116.9082,77,26); // greenwood
	AddStaticVehicle(411,-2062.4519,2067.9919,53.7713,0.8677,123,1); // infernus
	AddStaticVehicle(421,-1935.0779,2067.6655,62.5057,3.2639,13,1); // washington
	AddStaticVehicle(411,-1808.0939,2070.0679,71.9775,184.8690,123,1); // infernus
	AddStaticVehicle(522,-1935.8805,2125.7202,70.3910,3.0397,3,8); // nrg-500
	AddStaticVehicle(506,-2062.9570,2122.7068,61.2139,0.4861,76,76); // supergt
	AddStaticVehicle(470,-2260.3552,2119.2246,35.0059,269.0603,43,0); // patriot
	AddStaticVehicle(445,-2255.1091,2031.0229,28.6719,249.9727,35,35); // Admiral
	AddStaticVehicle(445,-2207.7668,2033.6689,24.3929,245.4705,35,35); // Admiral
	AddStaticVehicle(424,-2108.5117,1893.6433,6.3347,190.2502,2,2); // BF-Injection
	AddStaticVehicle(439,-2034.4636,1668.3163,3.6367,225.4763,8,17); // stallion
	AddStaticVehicle(439,-1955.5609,1618.7642,3.6361,51.3651,8,17); // stallion
	AddStaticVehicle(470,-1570.3871,2060.1624,3.4326,92.3437,43,0); // patriot
	AddStaticVehicle(475,-1816.2472,1868.4463,3.6264,179.1550,17,1); // Sabre
	AddStaticVehicle(475,-1855.2803,1874.0624,3.6245,358.4330,17,1); // Sabre
	AddStaticVehicle(475,-1873.3436,1865.6116,3.6264,269.2017,17,1); // sabre
	AddStaticVehicle(411,-2206.2976,1386.2976,10.8037,180.2781,116,1); // Infernus
	AddStaticVehicle(405,-2245.4548,1379.4526,10.9515,270.3546,75,1); // Stallion
	AddStaticVehicle(410,-2196.5503,1375.6223,10.7359,358.4975,9,1); // Manana
	AddStaticVehicle(407,-2189.9316,1341.5773,11.3075,90.9481,3,1); // Firetruck
	AddStaticVehicle(407,-2191.1328,1348.3677,11.3112,91.4643,3,1); // Firetruck
	AddStaticVehicle(420,-2099.5642,1262.9612,8.6038,93.6005,6,1); // Taxi-taxi
	AddStaticVehicle(420,-2099.2500,1254.3348,8.6063,92.4101,6,1); // Taxi-taxi
	AddStaticVehicle(420,-2098.8862,1244.9683,8.6063,271.2692,6,1); // Taxi-taxi
	AddStaticVehicle(420,-2091.1445,1200.6191,8.5247,179.6928,6,1); // Taxi
	AddStaticVehicle(420,-2091.1655,1183.3802,8.5213,181.2196,6,1); // taxi
	AddStaticVehicle(420,-2080.2715,1243.9781,8.5217,358.9134,6,1); // taxi
	AddStaticVehicle(420,-2079.7468,1267.1239,8.5503,1.9172,6,1); // taxi
	AddStaticVehicle(420,-2090.7036,1297.5591,8.5208,357.9116,6,1); // taxi
	AddStaticVehicle(420,-2090.5168,1316.3845,8.5217,359.1403,6,1); // taxi
	AddStaticVehicle(420,-2099.7285,1320.5417,9.4925,88.3367,6,1); // taxi
	AddStaticVehicle(420,-2099.9658,1310.1903,9.5478,271.3978,6,1); // taxi


//TRAINS - No tracks in Shoreside Vale?
//	AddStaticVehicle(537,-1943.3127,158.0254,27.0006,357.3614,121,1);
//	AddStaticVehicle(569,-1943.3127,158.0254,27.0006,357.3614,121,1);
//	AddStaticVehicle(569,-1943.3127,158.0254,27.0006,357.3614,121,1);
//	AddStaticVehicle(569,-1943.3127,158.0254,27.0006,357.3614,121,1);

//PICKUPS - On SV soon
	if(gRoundTime > 0) SetTimer("GameModeExitFunc", gRoundTime, 0);

	return 1;
}

//------------------------------------------------------------------------------
public OnPlayerConnect(playerid)
{
	GameTextForPlayer(playerid,"Shoreside Vale: ~r~TDM",2500,5);
	GivePlayerMoney(playerid, 1000);
	SetPlayerColor(playerid, COLOR_ORANGE); // Set the player's color to inactive
	SendClientMessage(playerid, COLOR_YELLOW, "Welcome to GTAU:MP - Shoreside Vale TDM");
	SendClientMessage(playerid, COLOR_YELLOW, "Created By: Lon");

	return 1;
}

//------------------------------------------------------------------------------
public OnPlayerSpawn(playerid)
{
	SetPlayerInterior(playerid,0);

	if(gTeam[playerid] == TEAM_PILOT) {
		SetPlayerColor(playerid,COLOR_GREEN); // Green
	}
	else if(gTeam[playerid] == TEAM_WORKER) {
		SetPlayerColor(playerid,COLOR_ORANGE); // Red
	}
	else if(gTeam[playerid] == TEAM_RICH) {
		SetPlayerColor(playerid,COLOR_RED); // Yellow
	}
	else if(gTeam[playerid] == TEAM_POLICE) {
		SetPlayerColor(playerid,COLOR_BLUE); // Pink
	}
	else if(gTeam[playerid] == TEAM_CIVILIAN) {
		SetPlayerColor(playerid,COLOR_GREY); // Blue
	}
	else if(gTeam[playerid] == TEAM_NOODLE) {
		SetPlayerColor(playerid,COLOR_LIGHTBLUE); // Light Blue
	}
	else if(gTeam[playerid] == TEAM_TAXI) {
		SetPlayerColor(playerid,COLOR_YELLOW); // Light Blue
	}
	return 1;
}

//------------------------------------------------------------------------------
public OnPlayerDeath(playerid, killerid, reason)
{
	if(killerid == INVALID_PLAYER_ID) {
        SendDeathMessage(INVALID_PLAYER_ID,playerid,reason);
	} else {
        if(gTeam[killerid] != gTeam[playerid]) {
	    	// Valid kill
	    	SendDeathMessage(killerid,playerid,reason);
			SetPlayerScore(killerid,GetPlayerScore(killerid)+1);
			GivePlayerMoney(killerid, 1000);
		}
		else {
			//Team Killer!
			new warning[256];
			format(warning, sizeof(warning), "Be careful! You have been punished for teamkilling.");
			SendClientMessage(killerid, 0xFFFF00AA, warning);
			SendDeathMessage(killerid,playerid,reason);
			GivePlayerMoney(killerid, -1000);
			SetPlayerScore(killerid, GetPlayerScore(killerid) - 1);
		}
	}
 	return 1;
}

//------------------------------------------------------------------------------
public SetupPlayerForClassSelection(playerid)
{
	SetPlayerInterior(playerid,0);
	SetPlayerPos(playerid,-1887.9119,2338.6194,215.9416);
	//SetPlayerFacingAngle(playerid, 90.0);
	SetPlayerCameraPos(playerid,1887.0548,2340.6799,215.9416);
	SetPlayerCameraLookAt(playerid,-1887.9119,2338.6194,215.9416);
}

//------------------------------------------------------------------------------
public OnPlayerRequestClass(playerid, classid)
{
	SetPlayerClass(playerid, classid);
	SetupPlayerForClassSelection(playerid);
	gPlayerClass[playerid] = classid;

	switch (classid) {
	    case 0:
	        {
				GameTextForPlayer(playerid, "~g~Pilot", 500, 3);
				SetPlayerCameraPos(playerid,-2461.8516,1143.5411,11.0766);
				SetPlayerColor(playerid,COLOR_GREEN);
			}
		case 1:
		    {
				GameTextForPlayer(playerid, "~g~Worker", 500, 3);
                SetPlayerCameraPos(playerid,-2441.3616,1758.2761,48.7953);
                SetPlayerColor(playerid,COLOR_ORANGE);
			}
		case 2:
	        {
				GameTextForPlayer(playerid, "~g~Rich", 500, 3);
				SetPlayerCameraPos(playerid,-1730.6492,2074.3669,62.6043);
				SetPlayerColor(playerid,COLOR_RED);
			}
		case 3:
	        {
				GameTextForPlayer(playerid, "~g~Police", 500, 3);
				SetPlayerCameraPos(playerid,-2621.8325,1748.5649,58.8238);
				SetPlayerColor(playerid,COLOR_BLUE);
			}
		case 4:
	        {
				GameTextForPlayer(playerid, "~g~Civilian", 500, 3);
				SetPlayerCameraPos(playerid,-2011.1569,1780.8140,18.8317);
				SetPlayerColor(playerid,COLOR_GREY);
			}
		case 5:
	        {
				GameTextForPlayer(playerid, "~g~Punk Noodles", 500, 3);
				SetPlayerCameraPos(playerid,-2384.3594,1591.1714,33.7384);
				SetPlayerColor(playerid,COLOR_LIGHTBLUE);
			}
		case 6:
	        {
				GameTextForPlayer(playerid, "~g~Taxi Drivers", 500, 3);
				SetPlayerCameraPos(playerid,-2106.3284,1244.6006,11.2992);
				SetPlayerColor(playerid,COLOR_YELLOW);
			}
	}

	return 1;
}

//------------------------------------------------------------------------------
public GameModeExitFunc()
{
	GameModeExit();
	return 1;
}

//------------------------------------------------------------------------------
SetPlayerClass(playerid, classid) {
	if(classid == 0) {
		gTeam[playerid] = TEAM_PILOT;
	} else if(classid == 1) {
		gTeam[playerid] = TEAM_WORKER;
	} else if(classid == 2) {
		gTeam[playerid] = TEAM_RICH;
	} else if(classid == 3) {
		gTeam[playerid] = TEAM_POLICE;
	} else if(classid == 4) {
		gTeam[playerid] = TEAM_CIVILIAN;
	} else if(classid == 5) {
 		gTeam[playerid] = TEAM_NOODLE;
	} else if(classid == 6) {
 		gTeam[playerid] = TEAM_TAXI;
	}
	return 1;
}

strtok(const string[], &index)
{
	new length = strlen(string);
	while ((index < length) && (string[index] <= ' '))
	{
		index++;
	}

	new offset = index;
	new result[20];
	while ((index < length) && (string[index] > ' ') && ((index - offset) < (sizeof(result) - 1)))
	{
		result[index - offset] = string[index];
		index++;
	}
	result[index - offset] = EOS;
	return result;
}

//------------------------------------------------------------------------------

