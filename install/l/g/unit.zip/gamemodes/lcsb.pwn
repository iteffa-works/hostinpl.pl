/******************************************************************************\
						    Area 51 - GTAU Port.
						    Area 51 = Subway.
\******************************************************************************/

#include <a_samp>



#define TEAM_ATTACK 1
#define TEAM_DEFENCE 2

#define CHECKPOINT_NONE 0
#define CHECKPOINT_SUBWAY 1

#define DEFENCE_WIN 0
#define ATTACK_WIN 1

#define COLOR_GREY 0xAFAFAFAA
#define COLOR_GREEN 0x33AA33AA
#define COLOR_RED 0xAA3333AA
#define COLOR_YELLOW 0xFFFF00AA

forward DefenceWin();
forward GameModeExitFunc();

new gTeam[MAX_PLAYERS];
new gPlayerClass[MAX_PLAYERS];
new gPlayerCheckpointStatus[MAX_PLAYERS];
new gRoundTimer;
new gRoundTime = 600000;					// Round time - 10 mins

main()
{

	print("\n--------------------------");
	print(" Subway breakin (Area 51 GTAU Port)");
	print("----------------------------n");

}



//---------------------------------------------------------



public OnGameModeInit()
{
	SetGameModeText("Subway Break In");
	SetWorldTime(12);

	AddPlayerClass(111,-157.1493,946.3256,18.9262,158.7158, 3, 0, 23, 1000, 25, 100); // Mafia dude - attack
	
	AddPlayerClass(287,-425.0453,1327.8787,-17.6992,346.8971, 4, 0, 32, 1000, 31, 5000); // defence
	AddPlayerClass(70,-415.5652,1359.3379,-20.5688,177.6955, 4, 0, 24, 1000, 32, 1000); // defence

	gRoundTimer = SetTimer("DefenceWin", gRoundTime, 0);
	return 1;

}

public OnPlayerEnterVehicle(playerid, vehicleid, ispassenger)
{
	return 1;
}

stock IsVehicleBeingDriven(vehicleid)
{
	new players = GetMaxPlayers();
	for(new i=0; i<players; i++)
	{
		if(IsPlayerInVehicle(i, vehicleid) && GetPlayerState(i) == PLAYER_STATE_DRIVER) return true;
	}
	return false;
}

//---------------------------------------------------------



public DefenceWin()
{
	EndTheRound(DEFENCE_WIN);
}



//---------------------------------------------------------



public OnPlayerConnect(playerid)
{
	GameTextForPlayer(playerid,"~w~Subway ~b~Break in!",4000,3);
	SetPlayerColor(playerid,COLOR_GREY);
	return 1;
}


//---------------------------------------------------------



SetupPlayerForClassSelection(playerid)
{
	SetPlayerInterior(playerid,0);
	SetPlayerFacingAngle(playerid,262.9115);
	SetPlayerPos(playerid,-197.9986,937.0609,14.9166);
	SetPlayerCameraPos(playerid,-193.2472,936.6467,14.8986);
	SetPlayerCameraLookAt(playerid,-197.9986,937.0609,14.9166);
	return;

}


//---------------------------------------------------------



SetPlayerTeamFromClass(playerid, classid)
{
	if(classid == 0)
	{
		gTeam[playerid] = TEAM_ATTACK;

	}
	else if(classid == 1 || classid == 2)
 	{
	    gTeam[playerid] = TEAM_DEFENCE;
	}
}



//---------------------------------------------------------



public OnPlayerRequestClass(playerid, classid)
{
	SetPlayerTeamFromClass(playerid, classid);
	SetupPlayerForClassSelection(playerid);
	gPlayerClass[playerid] = classid;
	switch (classid)
	{
		case 0:
		{
			GameTextForPlayer(playerid, "~r~Attack", 1000, 3);
		}
	    case 1, 2:
     	{
			GameTextForPlayer(playerid, "~g~Defence", 1000, 3);
		}
	}
	return 1;
}



//---------------------------------------------------------



public OnPlayerSpawn(playerid)
{
	SetPlayerToTeamColour(playerid);
	switch (gPlayerClass[playerid])
	{
	    case 0:
     	{
			gPlayerCheckpointStatus[playerid] = CHECKPOINT_SUBWAY;
	 		SetPlayerCheckpoint(playerid,-434.8197,1312.9216,-19.6541,5.0);
			SetPlayerInterior(playerid,0);
			GameTextForPlayer(playerid, "Go and attack the ~r~subway!", 2000, 5);
		}
	    case 1, 2:
     	{
 			gPlayerCheckpointStatus[playerid] = CHECKPOINT_NONE;
			GameTextForPlayer(playerid, "Defend the subway!", 2000, 5);
			SetPlayerInterior(playerid,0);
		}
	}
	return 1;
}


//---------------------------------------------------------


SetPlayerToTeamColour(playerid)
{
	if(gTeam[playerid] == TEAM_ATTACK)
	{
		SetPlayerColor(playerid,COLOR_RED); // Red
	}
	else if(gTeam[playerid] == TEAM_DEFENCE)
	{
	    SetPlayerColor(playerid,COLOR_GREEN); // Green
	}
}



//---------------------------------------------------------



public OnPlayerEnterCheckpoint(playerid)
{
	switch (gPlayerCheckpointStatus[playerid])
	{
		case CHECKPOINT_SUBWAY:
  		{
    		DisablePlayerCheckpoint(playerid);
      		gPlayerCheckpointStatus[playerid] = CHECKPOINT_NONE;
        	EndTheRound(ATTACK_WIN);
    	}
  		default:
    	{
			DisablePlayerCheckpoint(playerid);
		}
	}
	return 1;
}



//---------------------------------------------------------



public OnPlayerDeath(playerid, killerid, reason)
{
	if (killerid != INVALID_PLAYER_ID)
	{
		if (gTeam[playerid] == gTeam[killerid])
		{
			SetPlayerScore(killerid, GetPlayerScore(killerid) - 1);
		}
		else
		{
			SetPlayerScore(killerid, GetPlayerScore(killerid) + 1);
		}
	}
	SendDeathMessage(killerid, playerid, reason);
	DisablePlayerCheckpoint(playerid);
	gPlayerCheckpointStatus[playerid] = CHECKPOINT_NONE;
	SetPlayerColor(playerid,COLOR_GREY);
 	return 1;
}



//---------------------------------------------------------



EndTheRound(winner)
{
	switch (winner)
	{
	    case ATTACK_WIN:
	    {
	        GameTextForAll("The attackers broke into the subway.", 2000, 5);
	        KillTimer(gRoundTimer);
	    }
	    case DEFENCE_WIN:
	    {
	        GameTextForAll("The subway was successfully defended.", 2000, 5);
	    }
	}
	SetTimer("GameModeExitFunc", 5000, 0);
}



//---------------------------------------------------------



public GameModeExitFunc()
{
	GameModeExit();
}

